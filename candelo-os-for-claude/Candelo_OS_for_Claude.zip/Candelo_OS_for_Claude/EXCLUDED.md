# EXCLUDED.md — what was intentionally left out, and why

This kit is the **operating system and tooling** — the reusable way of working — not anyone's
private business. Before packaging, the whole kit was grepped for secret patterns and personal
data; everything found was stripped or replaced with a placeholder. This file is the receipt so
the sender can confirm it's safe to share.

## Verification run (on the final kit)

| Scan | Pattern | Result |
|------|---------|--------|
| API keys / secrets | `sk_live_`, `sk_test_`, `pk_live_`, `whsec_`, `ghp_`, `github_pat_`, `xox*`, AWS `AKIA…`, `-----BEGIN…`, bearer tokens, `ADMIN_TOKEN`, app passwords | **None present** |
| Emails / phone numbers | email + phone regexes, owner's address | **None present** |
| Personal / business names | owner name, every venture/brand name, recipient name | **None present in file content** (only false-positive substrings like "bill" inside "billed"/"model bill") |
| Sender's product name | the kit's own title / folder / zip / PDF filenames | **"Candelo OS" is deliberately retained as the product + sender brand** — it is how the sender names and signs their own system for the person they're handing it to. It is NOT a venture, customer, or private-data leak. If you want zero company-name exposure (e.g. before any onward re-sharing), rename the folder/zip/PDF to the kit's neutral internal identity (`portablebrain`) — the file *contents* already use the `{COMPANY}` placeholder, so only the package labels carry the name. |
| Absolute user paths | `/Users/<name>/…` | **None** — all replaced with `$HOME` or the `__BRAIN_ROOT__` install token |
| Internal tracking IDs | `CHG-`, `FLAG-`, `REC-` codes | Stripped from shipped files (the GOV-#### strings remaining are generic example pointer filenames in a template, not private content) |

### Independent re-audit (from scratch, on the shipped zip)

The packaged zip was unzipped and audited byte-for-byte by a separate pass that assumed it was NOT
clean. That pass caught residual private content that an earlier grep had missed — all inside the
reply-gate spec files (`learning_system_spec.md`, `core_laws.md`, and a comment in `lint_reply.py`):
a vendor/pricing example (a named voice vendor + a specific monthly price), the owner's exact local
model/hardware config, a business-strategy section, a dated personal note, the named device, and
several cross-references to files that don't ship. All were genericized to placeholders or removed,
and `__pycache__`/`.pyc` build artifacts were excluded from the package. The table above reflects
the kit **after** those fixes. The lesson is encoded as LAW-07 (`audit_before_third_party_send`):
a "safe to send" claim is only earned by a shown, independent audit — never by a prior clean claim.

## What was removed or replaced

**1. Every secret — none shipped.** No API keys, tokens, webhook secrets, app passwords, or admin
tokens appear anywhere in the kit. The tools are designed to run with **no API key at all** (local
Python / local browser / local embeddings), so there were no credentials to carry.

**2. All personal and business identifiers — replaced with placeholders.**
- The owner's name → `{OWNER}`.
- The company name → `{COMPANY}` **in all file content** (the kit title / zip / PDF filenames intentionally keep the "Candelo OS" product brand — see the "Sender's product name" row above).
- Every venture/brand name was removed. The brain digest generator (`gen_state.py`) used to have
  real project names hardcoded; those were extracted into an editable `projects.json` that now
  ships with two **generic example projects** ("ProjectOne", "ProjectTwo") for the recipient to
  replace.
- The recipient's own name does not appear in the kit either.

**3. All machine-specific paths — replaced.**
- The owner's absolute brain path → a `__BRAIN_ROOT__` token that each installer fills in from the
  recipient's own `BRAIN_ROOT` at install time.
- Personal home subpaths (`/Users/<name>/.local`, `.cargo`, `.claude`) → `$HOME/…`.
- LaunchAgent labels and the environment variable were renamed off the owner's namespace to a
  neutral one (`com.portablebrain.*`, `BRAIN_ROOT`).

**4. Private business data — never included in the first place.** The kit copies only the three
tool directories plus freshly written, generalized docs. It does **not** contain:
- The portfolio canon (priorities, build phases, pricing, contracts, venture strategy).
- Any per-venture state files, warnings lists, or research.
- Customer or lead records of any kind.
- The owner's personal memory/preference files.
- The mistake ledger's accumulated data (only the empty schema ships; it fills on first use).
- The full feedback-rule library (only the consolidated six-law spec ships, which is methodology,
  not business data).
- Runtime logs, caches, backups, the live `_STATE.md`, and the Drive-mirror script (which is
  specific to one person's Drive).

## What deliberately stays (and why it's safe)

- **The six core laws and the way-of-working** — this is methodology, the whole point of the kit.
- **The three tools' source code** — utility code with no embedded secrets or data.
- **The installers and self-tests** — they reference the recipient's own folder via the install
  token, not anyone else's.
- **Generic example config** (`projects.json`) — placeholders, no real data.

## How to re-verify yourself

```bash
cd Candelo_OS_for_Claude
grep -rniE "sk_live_|whsec_|ghp_|github_pat_|AKIA|ADMIN_TOKEN|@gmail|/Users/[a-z]+/" .
# expect: no matches (aside from $HOME-style paths)
```
