# SETUP — install {COMPANY} OS for Claude on your Mac

One clear path. Everything here is **$0 and local** — no API keys, no paid services. The whole
kit installs in a few minutes. You only need a Mac (the background services use macOS LaunchAgents)
and Python 3.

> **Placeholders:** before you start, open `CLAUDE.md` and replace `{OWNER}` with your name and
> `{COMPANY}` with your workspace name (find-and-replace). Then point `_tools/bulletproof_brain/projects.json`
> at your own projects (see step 3).

---

## Step 0 — pick your brain folder

Your "brain" is just a folder on your Mac where your notes, project files, and this tooling live.
It can be a new empty folder or an existing project folder. Pick it and remember its full path.
Example: `~/Documents/Claude/Projects/my-brain`.

## Step 1 — drop the kit in

Copy this kit's contents into your brain folder so the tools land at `<brain>/_tools/…` and
`CLAUDE.md` sits at the root:

```bash
# from inside the unzipped kit folder:
export BRAIN_ROOT="$HOME/Documents/Claude/Projects/my-brain"   # <- your folder
mkdir -p "$BRAIN_ROOT"
cp -R _tools "$BRAIN_ROOT/"
cp CLAUDE.md "$BRAIN_ROOT/"
```

Keep that `BRAIN_ROOT` set for the rest of setup (every installer reads it). If you open a new
terminal, set it again.

## Step 2 — install the brain auto-updater (one command)

```bash
bash "$BRAIN_ROOT/_tools/bulletproof_brain/install_bulletproof_brain.sh"
```

This makes the scripts runnable, installs a background agent that regenerates your `_STATE.md`
big-picture digest on every file change and nightly, and runs a self-test that prints PASS/FAIL.
To remove it later: `bash "$BRAIN_ROOT/_tools/bulletproof_brain/uninstall_bulletproof_brain.sh"`.

**One physical thing only you can do:** give the background agent Full Disk Access so it can write
freely — System Settings → Privacy & Security → Full Disk Access → add `/bin/bash`. (If you skip it,
everything still works except an optional Drive mirror.)

## Step 3 — describe your projects

Edit `$BRAIN_ROOT/_tools/bulletproof_brain/projects.json` — replace the two example projects with
your own and point each at its status file. The digest builds from these; any file that doesn't
exist just shows "(not found)" instead of breaking. Re-run to see it:

```bash
python3 "$BRAIN_ROOT/_tools/bulletproof_brain/gen_state.py"
open "$BRAIN_ROOT/_STATE.md"
```

## Step 4 — install the research service (one command)

```bash
bash "$BRAIN_ROOT/_tools/crawl4ai_research/install_crawl4ai.sh"
# add --with-searxng for deep meta-search
```

This creates an isolated Python environment, installs Crawl4AI + a headless browser, runs an
always-on local service at `http://127.0.0.1:8870`, and self-tests by crawling a real JavaScript
page. After this, your Claude fetches clean web content with:

```bash
"$BRAIN_ROOT/_tools/crawl4ai_research/venv/bin/python" \
  "$BRAIN_ROOT/_tools/crawl4ai_research/research_client.py" <url>
```

## Step 5 — the reply gate (nothing to install)

The enforcement layer is just scripts. Your Claude runs the gate on a draft before sending it:

```bash
cd "$BRAIN_ROOT/_tools/reply_gate"
echo "<draft text>" | python3 lint_reply.py --ask "what was asked for" --log
python3 ledger.py report          # see recurrence counts
```

Exit code `0` = APPROVED, `1` = REVISE. Wire it into your review step so it runs before any
consequential reply.

---

## How your Claude should use each tool (paste-ready summary for your assistant)

- **Orient first.** Every session, read `_STATE.md` for the big picture, then work. It's
  auto-regenerated, so it's never stale.
- **Stay current.** You don't run the brain updater by hand — the background agent does it on every
  file change and nightly. Just write files; they get indexed.
- **Research well.** For any web research, fetch through the local Crawl4AI service so JavaScript
  pages come back as clean Markdown, not empty shells.
- **Gate your replies.** Before any consequential reply, run it through `lint_reply.py`. If it says
  REVISE, fix the flagged law and re-run. The ledger makes a skipped gate visible the next morning.
- **Follow the six laws** in `CLAUDE.md` / `core_laws.md` on every reply.

---

## Optional — phone-native deploy

To publish static sites that update automatically (nothing runs on your Mac): create a GitHub
account + an empty repo, generate a fine-grained token scoped to that repo (Contents, Workflows,
Pages = read/write), and hand the token to your Claude. A GitHub Action republishes the site on
every push. The one-time repo + token creation is doable from your phone in Safari or the GitHub
app. `surge.sh` is a quick fallback if you need a site up before the repo is wired.

---

## What this is NOT

This kit is the **operating system and tooling** — the way of working — not anyone's private
business data. It ships with zero secrets, zero customer data, and generic placeholder projects.
See `EXCLUDED.md` for exactly what was left out and why.
