# {COMPANY} OS for Claude — Portable Edition

**A way of using Claude, packaged so you can install it and your Claude works the same way.**

This is not a chatbot prompt and not a single tool. It's a small operating system: a set of
working habits Claude adopts, plus three background tools that keep your "brain" (your folder of
notes and projects) current, enforce quality on every reply, and make web research actually good.
It was built and used daily by one solo operator running several businesses, then generalized and
stripped of all private data so it's safe to hand to someone else.

---

## What you get

**A way of working** (in `CLAUDE.md`). Claude reads this on load and adopts eight habits and seven
hard rules — research before asking, build don't ask, deliver finished things you can open on your
phone, complete the loop so nothing bounces back to you, plain English, and more. The short version:
*you create accounts and connect Claude to them; Claude does the rest.*

**Three tools** (in `_tools/`), each with a one-command installer and its own README:

1. **bulletproof_brain** — keeps a one-page "big picture" of everything you're working on
   automatically up to date, and makes your videos, PDFs, and spreadsheets readable to Claude. You
   never run it; it runs itself on every file change and nightly. $0, all on your Mac.

2. **reply_gate** — a quality gate. Before Claude sends you something, it checks the draft against
   the seven rules and flags anything that breaks one, with the exact fix. It also counts how often
   each kind of mistake comes back, so slippage is visible instead of silent.

3. **crawl4ai_research** — a research upgrade. Most web pages today are half-empty until JavaScript
   runs; this turns any page into clean, complete text Claude can actually use. Open-source, no API
   key, no cost.

**A phone-native deploy pattern** so anything Claude builds for you (a landing page, a tool) goes
live on the web without you touching a terminal.

---

## Why it's built this way

The whole system exists to remove you as the bottleneck. The rules all push the same direction:
Claude should figure things out, do the work end-to-end, and hand you the finished result on your
phone — not a list of steps for you to run. The brain stays current on its own so any Claude
session, anywhere, instantly has the full picture. The reply gate exists because writing down a
rule isn't the same as following it — the gate forces the check at the moment Claude is about to
act.

---

## Get started

Open **`SETUP.md`** — it's one clear path, a few minutes, all free. The short version:

1. Pick a folder to be your "brain."
2. Copy this kit's `_tools/` and `CLAUDE.md` into it.
3. Run two one-line installers.
4. Tell Claude to read `CLAUDE.md` and work this way.

---

## Is it safe to install?

Yes. It ships with **no secrets, no customer data, and no private business information** — only
generic placeholder projects you replace with your own. `EXCLUDED.md` lists exactly what was left
out and why. Everything runs locally on your Mac at no cost; nothing phones home.

---

*Questions? The person who sent you this built it and uses it every day — ask them.*
