#!/usr/bin/env python3
"""
research_client.py — the one helper the agent calls to research the web well.

This is the wiring layer. Instead of a raw page fetch (HTML noise / empty JS
shells), any agent surface on the Mac calls this to get clean Markdown.

  CLI:
    python3 research_client.py <url>            # clean markdown to stdout
    python3 research_client.py --search "<q>"   # SearXNG results (if installed)

  In code (Claude Code / Dispatch on the Mac):
    from research_client import crawl, search
    md = crawl("https://example.com/some/js/page")

Behavior:
  1. Try the warm local service at http://127.0.0.1:8870 (fast — browser already up).
  2. If the service is down, fall back to running Crawl4AI inline (slower cold start).
  3. Honest failure: print exactly why, never a silent empty string.

$0, local, no API key, no lock-in.
"""

import json
import os
import sys
import urllib.parse
import urllib.request

SERVICE = os.environ.get("RESEARCH_URL", "http://127.0.0.1:8870")


def _service_get(path):
    with urllib.request.urlopen(f"{SERVICE}{path}", timeout=90) as r:
        return json.loads(r.read().decode("utf-8", "ignore"))


def crawl(url):
    """Return clean Markdown for a URL. Tries the local service, then inline."""
    try:
        out = _service_get("/crawl?url=" + urllib.parse.quote(url, safe=""))
        if out.get("ok"):
            return out["markdown"]
    except Exception:
        pass  # service down -> inline fallback
    return _crawl_inline(url)


def _crawl_inline(url):
    import asyncio
    from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig
    extra = ["--no-sandbox", "--disable-gpu"]
    proxy = os.environ.get("CRAWL4AI_PROXY", "").strip()
    if proxy:
        extra.append(f"--proxy-server={proxy}")
    bc = BrowserConfig(headless=True, browser_type="chromium", extra_args=extra)
    exe = os.environ.get("CRAWL4AI_EXECUTABLE_PATH", "").strip()
    if exe:
        try:
            bc.browser_executable_path = exe
        except Exception:
            pass

    async def go():
        async with AsyncWebCrawler(config=bc) as c:
            res = await c.arun(url=url, config=CrawlerRunConfig(
                page_timeout=40000, wait_until="networkidle"))
            return res.markdown.raw_markdown if hasattr(res.markdown, "raw_markdown") else str(res.markdown)

    return asyncio.run(go())


def search(query):
    """Return SearXNG meta-search results (if SearXNG is installed)."""
    return _service_get("/search?q=" + urllib.parse.quote(query, safe=""))


def main():
    args = sys.argv[1:]
    if not args:
        print("usage: research_client.py <url> | --search <query>", file=sys.stderr)
        sys.exit(2)
    if args[0] == "--search":
        print(json.dumps(search(" ".join(args[1:])), indent=2))
        return
    md = crawl(args[0])
    if not md:
        print("[research_client] no content returned — check the URL / service.", file=sys.stderr)
        sys.exit(1)
    print(md)


if __name__ == "__main__":
    main()
