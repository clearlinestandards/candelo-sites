# crawl4ai_research — the local research service

The "fetch + clean" upgrade for research. Turns any page — including JavaScript-rendered ones —
into clean, LLM-ready Markdown. **$0, open-source (MIT), no API key, no lock-in.** A deep
meta-search engine (SearXNG) is staged behind it.

Most modern pages are nearly empty until JavaScript runs, so a plain fetch returns a shell with no
real content. This runs a real headless browser locally, renders the page, and hands back the
finished text.

## Stand it up

```bash
export BRAIN_ROOT="$HOME/Documents/Claude/Projects/my-brain"
bash "$BRAIN_ROOT/_tools/crawl4ai_research/install_crawl4ai.sh"     # add --with-searxng for deep search
```

The installer creates an isolated Python environment, installs Crawl4AI + a headless browser, runs
an always-on local service, and self-tests by crawling a real JavaScript page (printing PASS/FAIL).
It is idempotent — safe to re-run.

## Use it (the research call)

```bash
venv/bin/python research_client.py <url>      # clean markdown (renders JS)
# in code:
from research_client import crawl, search
```

Service: `http://127.0.0.1:8870` · endpoints `/healthz`, `/crawl?url=`, `/search?q=`.

## Files
- `research_service.py` — the always-on local service (lazy browser → ~30 MB idle).
- `research_client.py` — the helper your agent calls (uses the warm service, falls back inline).
- `install_crawl4ai.sh` — one-command installer + self-test.
- `run_service.sh` / `com.portablebrain.research.plist` — the always-on background agent.
- `searxng_setup.sh` — staged SearXNG (Docker), only runs when invoked.

## Where it runs (honest)

Real crawling needs an open network and a system browser, so it runs on your **Mac**. A firewalled
sandbox can validate the engine but can't crawl the open web.

## Reverse
```bash
launchctl unload ~/Library/LaunchAgents/com.portablebrain.research.plist
```
Disable the auto-bootstrap (the brain auto-updater can install this on its own): set
`SKIP_CRAWL4AI_BOOTSTRAP=1` or delete `install_crawl4ai.sh`.
