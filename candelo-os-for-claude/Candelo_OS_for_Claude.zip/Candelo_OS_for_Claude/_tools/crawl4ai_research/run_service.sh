#!/bin/bash
# run_service.sh — launches the research service with the right python.
# Prefers the dedicated venv created by install_crawl4ai.sh; falls back to system python3.
set -uo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [ -x "$DIR/venv/bin/python" ]; then
  PY="$DIR/venv/bin/python"
else
  PY="$(command -v python3 || echo /usr/bin/python3)"
fi
exec "$PY" "$DIR/research_service.py"
