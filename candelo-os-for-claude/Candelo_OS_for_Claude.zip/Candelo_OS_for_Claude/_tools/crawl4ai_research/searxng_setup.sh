#!/bin/bash
# ==============================================================================
# searxng_setup.sh — STAGED deep-search (SearXNG) for the brain.
# ==============================================================================
# Crawl4AI is the lead pick and the core install; SearXNG is the second step:
# a free, self-hosted metasearch engine that queries 70+ engines at once and
# returns a clean JSON API the research service proxies at /search.
#
# Kept SEPARATE from the core installer so it never balloons the Crawl4AI setup.
# It runs ONLY when you invoke it (install_crawl4ai.sh --with-searxng, or
# directly). It uses the official Docker image — the standard, no-lock-in path.
#
# If Docker isn't installed, this prints a one-line, no-chore note and exits 0
# (the core Crawl4AI service keeps working without it).
# $0 / local / no API key.
# ==============================================================================
set -uo pipefail

PORT="${SEARXNG_PORT:-8888}"
NAME="brain-searxng"

if ! command -v docker >/dev/null 2>&1; then
  echo "  ⚠ SearXNG needs Docker, which isn't installed on this Mac."
  echo "    Crawl4AI (the lead pick) is fully working without it. SearXNG stays staged."
  echo "    When you want it: install Docker Desktop once, then re-run this with --with-searxng."
  exit 0
fi

echo "  Docker found — standing up SearXNG on http://127.0.0.1:$PORT ..."
# Idempotent: remove a prior container of the same name.
docker rm -f "$NAME" >/dev/null 2>&1 || true

# Run SearXNG with the JSON API format enabled (needed for the /search proxy).
docker run -d --name "$NAME" --restart unless-stopped \
  -p 127.0.0.1:${PORT}:8080 \
  -e "SEARXNG_BASE_URL=http://127.0.0.1:${PORT}/" \
  -e "SEARXNG_SEARCH_FORMATS=html,json" \
  searxng/searxng:latest >/dev/null 2>&1 \
  && echo "  SearXNG container started (auto-restarts)." \
  || { echo "  ✗ SearXNG container failed to start (see: docker logs $NAME)"; exit 1; }

# Brief health probe.
sleep 6
if curl -s --max-time 8 "http://127.0.0.1:${PORT}/search?q=test&format=json" | grep -q '"results"'; then
  echo "  ✓ SearXNG JSON API answering — research service /search is now live."
else
  echo "  ⚠ SearXNG started but JSON API didn't confirm yet (it may still be warming up)."
fi
exit 0
