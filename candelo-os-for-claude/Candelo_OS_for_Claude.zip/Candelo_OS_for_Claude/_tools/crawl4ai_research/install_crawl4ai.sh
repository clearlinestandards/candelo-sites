#!/bin/bash
# ==============================================================================
# install_crawl4ai.sh — one-paste installer + self-test for the brain
#                       local research service (Crawl4AI).
# ==============================================================================
# What it does, end to end, with NO further input:
#   1. creates a dedicated python venv (no system-python pollution)
#   2. pip installs crawl4ai into it
#   3. runs crawl4ai-setup -> downloads the headless browser + checks host deps
#   4. installs + loads the com.portablebrain.research LaunchAgent (always-on,
#      auto-restart, survives reboot) -> service at http://127.0.0.1:8870
#   5. SELF-TESTS by crawling a real JavaScript page end-to-end and confirming
#      the rendered content comes back as clean Markdown; prints PASS/FAIL.
#   6. optional:  --with-searxng  also stands up SearXNG (Docker) for deep search.
#
# Idempotent: safe to re-run. Everything is $0 / local / no API key / no lock-in.
# Reverse: launchctl unload ~/Library/LaunchAgents/com.portablebrain.research.plist
# ==============================================================================
set -uo pipefail

ROOT="${BRAIN_ROOT:-__BRAIN_ROOT__}"
if [ "$ROOT" = "__BRAIN_ROOT__" ] || [ ! -d "$ROOT" ]; then
  echo "ERROR: BRAIN_ROOT is not set to a real folder."
  echo "  Set it to YOUR brain workspace, then re-run, e.g.:"
  echo "    export BRAIN_ROOT=\"$HOME/Documents/Claude/Projects/your-brain\""
  exit 1
fi
DIR="$ROOT/_tools/crawl4ai_research"
VENV="$DIR/venv"
PLIST="com.portablebrain.research.plist"
PLIST_DST="$HOME/Library/LaunchAgents/$PLIST"
PORT="${RESEARCH_PORT:-8870}"
WITH_SEARXNG=0; [ "${1:-}" = "--with-searxng" ] && WITH_SEARXNG=1
PASS=0; FAIL=0; WARN=0
ok(){ echo "  ✓ PASS — $*"; PASS=$((PASS+1)); }
no(){ echo "  ✗ FAIL — $*"; FAIL=$((FAIL+1)); }
warn(){ echo "  ⚠ WARN — $*"; WARN=$((WARN+1)); }

echo "============================================================"
echo "the brain — Crawl4AI research service — installer + self-test"
echo "Dir: $DIR    Port: $PORT    SearXNG: $([ $WITH_SEARXNG = 1 ] && echo yes || echo no)"
echo "============================================================"

# --- 1. venv -----------------------------------------------------------------
echo "[1/6] Python venv..."
# Prefer a wheel-stable interpreter. Brand-new pythons (e.g. 3.14) often lack
# prebuilt wheels for crawl4ai's deps (lxml, playwright, …) and force slow/failing
# source builds — so pick 3.12 > 3.11 > 3.10 > 3.13 > generic python3 if present.
PY3=""
for cand in python3.12 python3.11 python3.10 python3.13 python3; do
  p="$(command -v $cand 2>/dev/null || true)"; [ -n "$p" ] && { PY3="$p"; break; }
done
[ -z "$PY3" ] && PY3="/usr/bin/python3"
echo "  using interpreter: $PY3 ($($PY3 -V 2>&1))"
# If a venv already exists but on a different/too-new interpreter, rebuild it.
if [ -x "$VENV/bin/python" ]; then
  CUR="$("$VENV/bin/python" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
  WANT="$("$PY3" -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null)"
  if [ "$CUR" != "$WANT" ]; then echo "  rebuilding venv ($CUR -> $WANT)"; rm -rf "$VENV"; fi
fi
if [ ! -x "$VENV/bin/python" ]; then "$PY3" -m venv "$VENV" || { echo "venv create failed"; exit 1; }; fi
PYV="$VENV/bin/python"
"$PYV" -m pip install --upgrade pip -q
echo "  venv: $VENV"

# --- 2. crawl4ai -------------------------------------------------------------
echo "[2/6] Installing crawl4ai (this is the only download of size)..."
"$PYV" -m pip install -q crawl4ai && echo "  crawl4ai installed." || { no "crawl4ai pip install failed"; }

# --- 3. browser + host deps --------------------------------------------------
echo "[3/6] Downloading headless browser (crawl4ai-setup)..."
"$VENV/bin/crawl4ai-setup" 2>&1 | tail -3 || "$PYV" -m playwright install chromium 2>&1 | tail -3
echo "  browser ready (or already present)."

# --- 4. LaunchAgent ----------------------------------------------------------
echo "[4/6] Installing always-on LaunchAgent..."
chmod +x "$DIR/run_service.sh" 2>/dev/null || true
mkdir -p "$HOME/Library/LaunchAgents"
launchctl list 2>/dev/null | grep -q com.portablebrain.research && launchctl unload "$PLIST_DST" 2>/dev/null || true
sed "s#__BRAIN_ROOT__#$ROOT#g" "$DIR/$PLIST" > "$PLIST_DST" && echo "  installed (paths set to $ROOT) -> $PLIST_DST"
launchctl load "$PLIST_DST" 2>/dev/null && echo "  loaded." || warn "launchctl load returned nonzero (checked below)"
sleep 5  # give the warm browser time to come up

# --- 5. SELF-TEST (real JS crawl, end to end) --------------------------------
echo "[5/6] SELF-TEST"
# T1 venv python + crawl4ai import
"$PYV" -c "import crawl4ai" 2>/dev/null && ok "crawl4ai imports in venv" || no "crawl4ai import failed"
# T2 service healthy
if curl -s --max-time 8 "http://127.0.0.1:$PORT/healthz" | grep -q '"ok": true'; then ok "service healthy on :$PORT"; else no "service not answering on :$PORT (see service.err.log)"; fi
# T3 the decisive proof: crawl a REAL JavaScript page and confirm rendered text
TESTURL="https://quotes.toscrape.com/js/"   # classic JS-rendered test site
RESP="$(curl -s --max-time 60 "http://127.0.0.1:$PORT/crawl?url=$TESTURL")"
if echo "$RESP" | "$PYV" -c "import sys,json; d=json.load(sys.stdin); md=d.get('markdown','');
import re; print('CHARS',len(md)); sys.exit(0 if (d.get('ok') and 'Einstein' in md) else 1)" ; then
  ok "rendered a JavaScript page into clean Markdown (found JS-injected content)"
else
  warn "JS self-test page didn't confirm — network or site issue; try: $VENV/bin/python $DIR/research_client.py $TESTURL"
fi
# T4 raw-vs-rendered contrast (proves the upgrade, not just that it ran)
"$PYV" - "$TESTURL" <<'PY' && ok "raw fetch is empty of JS content — rendering is what fills it (contrast confirmed)" || warn "contrast check inconclusive"
import sys,urllib.request
raw=urllib.request.urlopen(urllib.request.Request(sys.argv[1],headers={"User-Agent":"Mozilla/5.0"}),timeout=30).read().decode("utf-8","ignore")
sys.exit(0 if "Einstein" not in raw else 1)   # JS site: quote text absent from raw HTML
PY

# --- 6. SearXNG (optional, staged) -------------------------------------------
echo "[6/6] SearXNG (deep search)"
if [ $WITH_SEARXNG = 1 ]; then
  bash "$DIR/searxng_setup.sh" || warn "SearXNG setup reported an issue (see its output)"
else
  echo "  skipped (run with --with-searxng to add it; Crawl4AI leads, SearXNG is the second step)."
fi

echo "============================================================"
echo "RESULT: $PASS pass, $FAIL fail, $WARN warn"
echo "============================================================"
if [ "$FAIL" -eq 0 ]; then
  date +%s > "$DIR/.installed"   # sentinel: tells the auto-bootstrap it's done (don't re-run)
  echo "INSTALL OK. The research service is live at http://127.0.0.1:$PORT and"
  echo "will auto-start on boot. The agent fetches clean web content via:"
  echo "    $VENV/bin/python \"$DIR/research_client.py\" <url>"
else
  echo "INSTALL had failures above — nothing destructive ran. See service.err.log."
fi
[ "$WARN" -gt 0 ] && echo "NOTE: warnings are non-blocking (network/SearXNG/Docker). See messages above."
exit 0
