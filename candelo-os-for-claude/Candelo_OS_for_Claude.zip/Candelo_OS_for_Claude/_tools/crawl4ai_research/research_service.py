#!/usr/bin/env python3
"""
research_service.py — the brain local research service (Crawl4AI front door).

Runs as a tiny always-on HTTP service on the Mac (localhost only, $0, no
API key, no lock-in). It wraps Crawl4AI so any agent surface (Claude Code on the
Mac, Dispatch) can turn ANY page — including JavaScript-rendered ones — into
clean, LLM-ready Markdown with a single local call, instead of doing a raw fetch
that returns HTML noise or an empty shell.

Endpoints (GET):
  /healthz            -> {"ok": true, "engine": "crawl4ai", ...}
  /crawl?url=<URL>    -> {"ok": true, "url":..., "markdown": "...", "chars":...}
                         optional: &raw=1 returns the raw rendered HTML too
  /search?q=<QUERY>   -> proxies SearXNG at SEARXNG_URL if it's up (staged;
                         404 with a clear note if SearXNG isn't installed)

Design notes
  * stdlib http.server for the server (zero web-framework dependency).
  * One long-lived AsyncWebCrawler reused across requests (warm browser).
  * Cross-environment: honors CRAWL4AI_EXECUTABLE_PATH and CRAWL4AI_PROXY env
    vars so the identical file runs on the Mac (default chromium, no proxy) and
    in a firewalled test sandbox (headless-shell + proxy). On the Mac you set
    neither — it just works.
  * Bound to 127.0.0.1 only — never exposed off the machine.
"""

import asyncio
import json
import os
import threading
import urllib.parse
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOST = os.environ.get("RESEARCH_HOST", "127.0.0.1")
PORT = int(os.environ.get("RESEARCH_PORT", "8870"))
SEARXNG_URL = os.environ.get("SEARXNG_URL", "http://127.0.0.1:8888")
EXECUTABLE_PATH = os.environ.get("CRAWL4AI_EXECUTABLE_PATH", "").strip()
PROXY = os.environ.get("CRAWL4AI_PROXY", "").strip()

# --- one warm crawler, driven from a dedicated asyncio loop in its own thread ---
_loop = asyncio.new_event_loop()
_crawler = None
_crawler_lock = threading.Lock()


def _start_loop():
    asyncio.set_event_loop(_loop)
    _loop.run_forever()


threading.Thread(target=_start_loop, daemon=True).start()


def _run(coro):
    return asyncio.run_coroutine_threadsafe(coro, _loop).result()


async def _get_crawler():
    global _crawler
    if _crawler is not None:
        return _crawler
    from crawl4ai import AsyncWebCrawler, BrowserConfig
    extra = ["--no-sandbox", "--disable-gpu"]
    if PROXY:
        extra.append(f"--proxy-server={PROXY}")
    bc = BrowserConfig(headless=True, browser_type="chromium", extra_args=extra)
    if EXECUTABLE_PATH:
        try:
            bc.browser_executable_path = EXECUTABLE_PATH
        except Exception:
            pass
    c = AsyncWebCrawler(config=bc)
    await c.start()
    _crawler = c
    return _crawler


async def _crawl(url):
    from crawl4ai import CrawlerRunConfig
    c = await _get_crawler()
    res = await c.arun(url=url, config=CrawlerRunConfig(
        page_timeout=40000, wait_until="networkidle"))
    md = res.markdown.raw_markdown if hasattr(res.markdown, "raw_markdown") else str(res.markdown)
    return {"ok": bool(res.success), "url": url, "chars": len(md or ""),
            "markdown": md or "", "html": res.html if hasattr(res, "html") else ""}


def _searxng(query):
    u = f"{SEARXNG_URL}/search?q={urllib.parse.quote(query)}&format=json"
    try:
        with urllib.request.urlopen(u, timeout=20) as r:
            data = json.loads(r.read().decode("utf-8", "ignore"))
        results = [{"title": x.get("title"), "url": x.get("url"),
                    "content": x.get("content")} for x in data.get("results", [])[:15]]
        return {"ok": True, "query": query, "count": len(results), "results": results}
    except Exception as e:
        return {"ok": False, "query": query,
                "note": f"SearXNG not reachable at {SEARXNG_URL} ({type(e).__name__}). "
                        f"Run install_crawl4ai.sh --with-searxng to stand it up."}


class H(BaseHTTPRequestHandler):
    def _send(self, code, obj):
        body = json.dumps(obj).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, *a):  # quiet
        pass

    def do_GET(self):
        parsed = urllib.parse.urlparse(self.path)
        qs = urllib.parse.parse_qs(parsed.query)
        path = parsed.path
        try:
            if path == "/healthz":
                return self._send(200, {"ok": True, "engine": "crawl4ai",
                                        "port": PORT, "searxng_url": SEARXNG_URL,
                                        "proxy": PROXY or None})
            if path == "/crawl":
                url = (qs.get("url") or [""])[0]
                if not url:
                    return self._send(400, {"ok": False, "note": "missing ?url="})
                with _crawler_lock:                # 1 browser, 1-2 pages at a time (RAM-safe)
                    out = _run(_crawl(url))
                if not (qs.get("raw") or [""])[0]:
                    out.pop("html", None)
                return self._send(200, out)
            if path == "/search":
                q = (qs.get("q") or [""])[0]
                if not q:
                    return self._send(400, {"ok": False, "note": "missing ?q="})
                return self._send(200, _searxng(q))
            return self._send(404, {"ok": False, "note": f"unknown path {path}"})
        except Exception as e:
            return self._send(500, {"ok": False, "error": f"{type(e).__name__}: {e}"})


def main():
    srv = ThreadingHTTPServer((HOST, PORT), H)
    print(f"[brain-research] listening on http://{HOST}:{PORT}  (crawl4ai warm)")
    srv.serve_forever()


if __name__ == "__main__":
    main()
