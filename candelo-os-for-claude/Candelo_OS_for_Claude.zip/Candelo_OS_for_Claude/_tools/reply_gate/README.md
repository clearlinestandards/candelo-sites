# reply_gate — the enforcement layer

Writing a "law" into the brain is **not** the same as following it. The break is recall-and-enforce
at the moment of acting — especially on background tasks, where nothing forces a check. This folder
is the enforcement layer: the small set of rules that actually change behavior, each with a
**detectable signature** (the literal tell in a draft that you're about to break it), plus a
deterministic linter that scans for those tells. $0, standard library only.

## Files

| File | What it is |
|------|------------|
| `core_laws.md` | The six load-bearing laws, each with its detectable signature. The spec the linter reads. |
| `lint_reply.py` | **The gate.** Scans a draft for the six laws' signatures, returns APPROVED / REVISE + the exact law + the fix. Human or JSON output. |
| `ledger.py` + `mistake_ledger.json` | **The recurrence counter.** Tracks each mistake-class over time, gate-caught vs missed. Per-class report + a one-line morning digest. (`mistake_ledger.json` is created on first use.) |
| `learning_system_spec.md` | The full stack the gate sits in (search → gate → drift → eval → consolidation → fine-tune), built vs staged. |

## Use it

```bash
cd "$BRAIN_ROOT/_tools/reply_gate"

# gate a draft (the core move — run before any consequential reply)
python3 lint_reply.py --file draft.txt --ask "what was asked for" --log
echo "<draft text>" | python3 lint_reply.py --ask "show me the page" --log

# JSON, for wiring into another tool
python3 lint_reply.py --file draft.txt --json

# see the recurrence counts
python3 ledger.py report
python3 ledger.py report --daily      # one-line morning digest

# log something that was caught after the fact (the gate missed it)
python3 ledger.py add --law LAW-01 --caught-by missed --note "desktop-only deploy"
```

Exit code: `0` = APPROVED, `1` = REVISE — so it can gate a pipeline.

## The six laws (full text + signatures in `core_laws.md`)

1. **PHONE-FIRST** — operable/deployable from the phone; no desktop-only primary action.
2. **SHOW, DON'T INSTRUCT** — "show me X" = produce X, not a how-to.
3. **DELIVER THE USABLE ARTIFACT** — the real openable thing, not a description of it.
4. **TEST THE LIMIT BEFORE ASSERTING IT** — never say "I can't" without trying first.
5. **OPERATOR-LANGUAGE ENDING** — end on what was done / next / the one owner-only action; never "want me to?".
6. **PLAIN ENGLISH** — no jargon, no self-narration, no sycophancy.

## Honest limit

Nothing can *force* the gate to run on a background task — there's no hook engine off the main CLI.
Realistic enforcement = the gate exists as one command **+** the discipline to self-invoke it before
any consequential reply **+** the ledger making a skipped gate visible the next morning. It's a
discipline backed by a counter, not a hard interlock.

## Adding / tuning a law

Detectors live in `DETECTORS` inside `lint_reply.py` — each is a small function returning matched
phrases tied to one law ID. Keep precision high: a gate that cries wolf gets ignored. Add a law to
`core_laws.md` only when a miss **recurs**, not on first sight.
