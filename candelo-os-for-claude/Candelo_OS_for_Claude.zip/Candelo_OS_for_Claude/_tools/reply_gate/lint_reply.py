#!/usr/bin/env python3
"""
lint_reply.py — a deterministic PRE-REPLY GATE for the brain.

The diagnosis behind it: capturing a "law" into your notes is NOT learning.
The break is recall-and-enforce at the MOMENT of acting — especially on
background tasks, where nothing forces a check. This script is the enforcement: a deterministic
linter that scans a DRAFT reply for the textual signatures of the seven core laws
(see core_laws.md) BEFORE the draft is sent, and returns APPROVED or REVISE with
the exact law violated and the fix.

It is heuristic + regex, fully runnable in the sandbox (stdlib only, $0, no
model call), tunable, and machine-readable. Every detector is tied to one LAW_ID
from core_laws.md so a hit can be logged to mistake_ledger.json by class.

USAGE
  # lint a draft from a file
  python3 lint_reply.py --file draft.txt
  # lint a draft from stdin
  echo "paste this at your Mac: bash deploy.sh" | python3 lint_reply.py
  # lint an inline string
  python3 lint_reply.py --text "here's how you make a music video: 1. open..."
  # JSON only (for wiring into critic / other tools)
  python3 lint_reply.py --file draft.txt --json
  # tell the gate what the owner ASKED FOR (sharpens show-dont-instruct + cant-test)
  python3 lint_reply.py --file draft.txt --ask "show me the landing page"
  # also record any findings to the recurrence ledger
  python3 lint_reply.py --file draft.txt --log

EXIT CODE: 0 = APPROVED, 1 = REVISE (so it can gate a pipeline).

Tuning: every detector lives in DETECTORS below as a small dict. Add/loosen/
tighten patterns there; nothing else needs to change. Keep precision high —
a gate that cries wolf gets ignored, which enforces nothing.
"""

import argparse
import json
import re
import sys
import os

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------
# Helpers for "evidence of an attempt / a surfaced artifact" — these let a
# detector suppress itself when the draft already shows it did the right thing.
# ---------------------------------------------------------------------------

# Signs the draft contains evidence that a capability was actually TESTED
# (so an "I can't" is an honest, earned wall rather than an untested assertion).
ATTEMPT_EVIDENCE = re.compile(
    r"\b(i (ran|tried|tested|attempted|executed|checked)|"
    r"returned (an? )?(error|exit|non-?zero)|"
    r"exit code|stderr|traceback|"
    r"when i ran|after running|i just ran|"
    r"the command (failed|errored|returned)|"
    r"verified (that|by)|i confirmed by)\b",
    re.IGNORECASE,
)

# Signs the draft actually SURFACES an openable artifact (URL / present step).
ARTIFACT_SURFACED = re.compile(
    r"(https?://|present_files|\bI(?:'ve| have)? (attached|presented)\b|"
    r"tap (the|this) (link|card|file)|open(?:able)? (link|url)|here'?s the link)",
    re.IGNORECASE,
)

# A bare local file path used as if it were the deliverable.
BARE_PATH = re.compile(
    r"(?:/Users/[^\s`'\"]+|_tools/[^\s`'\"]+|_active/[^\s`'\"]+|"
    r"[\w/ .-]+\.(?:md|csv|pdf|pptx|docx|xlsx|html|json|zip))",
    re.IGNORECASE,
)

# Words in the user's ASK that mean "give me the thing itself", which makes a
# how-to / instruction block a LAW-02 violation rather than legitimately helpful.
ASK_FOR_ARTIFACT = re.compile(
    r"\b(show|see|view|look at|review|make me|build me|give me|create me|"
    r"i want (the|a|to see)|can'?t you (just )?show)\b",
    re.IGNORECASE,
)


def _strip_code_fences_keep_marker(text):
    """Return text with fenced code replaced by a sentinel so we can still
    detect that a shell block EXISTS without matching its inner words twice."""
    return re.sub(r"```.*?```", " <CODEBLOCK> ", text, flags=re.DOTALL)


# ---------------------------------------------------------------------------
# DETECTORS — each tied to one LAW_ID from core_laws.md.
# A detector returns a list of (matched_phrase, note) evidence tuples.
# ---------------------------------------------------------------------------

def d_phone_first(text, ask):
    """LAW-01 — Mac/Terminal-only deploy as the primary action."""
    hits = []
    patterns = [
        r"paste (this|the following|it) (at|on|in)[^.\n]*\bmac\b",
        r"\bopen terminal\b",
        r"\bin terminal:\b",
        r"run (this|the following|it)[^.\n]*\bin terminal\b",
        r"on your mac( mini)?\b",
        r"\bcd\s+[\"'/][^\n]*&&\s*claude\b",
        r"bash\s+[^\s]*deploy[^\s]*\.sh",
        r"\./deploy\b",
        r"\brun\s+[^\s]*\.sh\b",
        r"load the (launchagent|plist|launchd)",
        r"\bgraphify\s+update\s+\.",
    ]
    for p in patterns:
        for m in re.finditer(p, text, re.IGNORECASE):
            hits.append((m.group(0).strip(), "Mac/Terminal step presented as the owner's action"))
    # A fenced shell block with no phone-native alternative nearby is also a tell.
    if re.search(r"```(?:bash|sh|shell|zsh)?\b", text, re.IGNORECASE):
        if not re.search(r"(tap|shortcut|webhook|url|i'?ll (run|deploy|do)|automat)", text, re.IGNORECASE):
            hits.append(("```shell block```", "shell block with no phone-native / automated alternative offered"))
    return hits


def d_show_dont_instruct(text, ask):
    """LAW-02 — handed a how-to when the owner asked for the thing itself."""
    hits = []
    instruct_markers = [
        r"here'?s how (you|to)\b",
        r"\bsteps to\b",
        r"\bfollow these steps\b",
        r"\bto do this[:,]",
        r"\byou'?ll need to\b",
        r"\bguide to\b",
        r"\bwalkthrough\b",
        r"\binstructions (for|to)\b",
        r"^\s*1[\.\)]\s+.+\n\s*2[\.\)]\s+",  # an enumerated procedure
    ]
    found = []
    for p in instruct_markers:
        for m in re.finditer(p, text, re.IGNORECASE | re.MULTILINE):
            found.append(m.group(0).strip().splitlines()[0][:60])
    if not found:
        return hits
    # Only a violation if the ASK was for the artifact itself (or ask unknown
    # but the draft is dominated by procedure). If ask clearly requests steps
    # ("how do I", "explain", "walk me through"), suppress.
    ask_l = (ask or "").lower()
    ask_wants_steps = bool(re.search(r"\b(how do i|how to|explain|walk me through|teach me|what'?s the process)\b", ask_l))
    ask_wants_thing = bool(ASK_FOR_ARTIFACT.search(ask_l)) if ask else False
    if ask_wants_steps and not ask_wants_thing:
        return hits  # user explicitly asked for instructions
    note = ("the owner asked for the artifact, not instructions" if ask_wants_thing
            else "draft hands over a how-to; confirm the owner didn't ask for steps")
    for f in found:
        hits.append((f, note))
    return hits


def d_deliver_artifact(text, ask):
    """LAW-03 — references a deliverable but never surfaces it openably."""
    hits = []
    references_deliverable = re.search(
        r"\b(i'?ve created|i (made|built|generated|saved)|the (pdf|file|doc|deck|report|spreadsheet)"
        r"|it'?s (saved|in the folder|at)|everything is ready|the file is at|see the attached"
        r"|saved to|in the `?_active`?|in the `?_tools`?)\b",
        text, re.IGNORECASE,
    )
    if not references_deliverable:
        return hits
    if ARTIFACT_SURFACED.search(text):
        return hits  # it DID surface an openable thing — fine
    # references a deliverable, nothing openable surfaced
    bare = BARE_PATH.search(text)
    ev = references_deliverable.group(0).strip()
    note = "deliverable referenced but not surfaced as an openable link/attachment"
    hits.append((ev, note))
    if bare:
        hits.append((bare.group(0).strip()[:60], "bare file path offered as if it were the deliverable"))
    return hits


def d_test_limit(text, ask):
    """LAW-04 — 'I can't / do it manually' with no evidence of an attempt."""
    hits = []
    claim = re.search(
        r"\b(i can'?t\b|i'?m not able to|i (do not|don'?t) have the ability"
        r"|that'?s not possible for me|you'?ll have to do (it|this) (manually|yourself)"
        r"|you'?ll need to do (it|this) yourself|this requires you to|you have to do it manually)\b",
        text, re.IGNORECASE,
    )
    if not claim:
        return hits
    if ATTEMPT_EVIDENCE.search(text):
        return hits  # an earned wall — a real attempt is shown
    hits.append((claim.group(0).strip(), "limitation asserted with no evidence of an actual attempt"))
    return hits


def d_operator_ending(text, ask):
    """LAW-05 — non-operator / 'want me to?' ending + untranslated analyst-speak."""
    hits = []
    # Look only at the last ~400 chars for the ending check.
    tail = text[-400:]
    banned_endings = [
        r"want me to\b", r"should i\b", r"would you like me to\b",
        r"let me know if you'?d like", r"i can do .* if you want",
        r"do you want me to (verify|check|research|look into)",
        r"\bup to you\b", r"\beither works\b", r"pick whichever",
        r"\bthoughts\?\s*$", r"let me know\.?\s*$",
    ]
    for p in banned_endings:
        m = re.search(p, tail, re.IGNORECASE)
        if m:
            hits.append((m.group(0).strip(), "reply ends on an ask, not an operator landing (only the 5 carve-outs may ask)"))
    # Untranslated analyst-speak anywhere, with no "what you can do/say now".
    analyst = re.findall(
        r"\b(platform-level endorsement|data model|network-effect moat|margin unlock"
        r"|burden of proof reversal|year 2\+ play|pitch-sharpening|category-defining)\b",
        text, re.IGNORECASE,
    )
    if analyst and not re.search(r"what you can (now )?(say|do)", text, re.IGNORECASE):
        hits.append((analyst[0], "analyst-speak not translated into 'what you can say/do now'"))
    return hits


def d_plain_english(text, ask):
    """LAW-06 — self-naming canon-theater, jargon, sycophancy surfaced to the owner."""
    hits = []
    canon_theater = [
        r"the law is locked", r"\bper GOV-\d", r"\bper CHG-\d",
        r"i'?ve captured this to the brain", r"\blocked 20\d\d", r"this becomes canon",
        r"foundational (principle|law)", r"\bthe rule states\b",
    ]
    jargon = [
        r"\bagent architecture\b", r"\bLayer [012]\b", r"\bICM\b",
        r"\bthe harness\b", r"\bcontext window\b", r"\bRAG\b", r"\bthe seat\b",
    ]
    sycophancy = [r"\byou'?re right\b", r"\bgood point\b", r"\bgreat question\b", r"\babsolutely[!,. ]"]
    for label, group in (("canon-theater", canon_theater), ("jargon", jargon), ("sycophancy", sycophancy)):
        for p in group:
            m = re.search(p, text, re.IGNORECASE)
            if m:
                hits.append((m.group(0).strip(), f"{label} — say it plainly, don't surface internals to the owner"))
    return hits


def d_third_party_send(text, ask):
    """LAW-07 — declaring something 'safe to send / send-ready / sanitized /
    ready for <name>' to a THIRD PARTY without an independent audit shown.

    A clean-for-external-recipient claim is only allowed when the draft also
    SHOWS the audit that earns it (scan commands + hits/0-hits evidence). A bare
    'it's safe to send' with no shown verification is the violation."""
    hits = []
    claim = re.search(
        r"\b(safe|cleared|clear|ok(?:ay)?|good|fine|ready)\s+to\s+(send|share|ship|hand\s*off|forward|distribute|publish|deliver)\b"
        r"|\bsend[-\s]?ready\b"
        r"|\bready\s+(?:to|for)\s+(?:send|ship|share|hand|deliver|the\s+recipient|external|third[-\s]?part)"
        r"|\bready\s+for\s+[A-Z][a-z]+\b"          # "ready for Jay"
        r"|\bsanitiz(?:ed|e)\b|\b(?:fully\s+)?scrubbed\b"
        r"|\bcleared\s+to\s+(?:send|share|ship)\b"
        r"|\bno\s+(?:leaks|secrets|pii)\b|\bnothing\s+(?:leaks|leaked)\b"
        r"|\bclean\s+to\s+(?:send|share|ship)\b",
        text, re.IGNORECASE,
    )
    if not claim:
        return hits
    # Suppress if the draft actually SHOWS an independent audit was run:
    # scan commands, hit/0-hit evidence, an audit artifact, or the gate itself.
    audit_shown = re.search(
        r"\b(audit(?:ed|ing)?|independently|re-?ran|re-?audit|"
        r"grep\s+-|scanned|secret\s+scan|pii\s+scan|"
        r"0\s+hits|zero\s+hits|no\s+hits|hits?\s*[:|]|"
        r"verified\s+(?:by|that|from)|evidence(?:\s|:)|"
        r"unzip(?:ped)?|md5|lint_reply|EXCLUDED\.md|AUDIT\s+REPORT)\b",
        text, re.IGNORECASE,
    )
    if audit_shown:
        return hits  # the claim is backed by a shown audit — allowed
    hits.append((claim.group(0).strip(),
                 "declared clean/safe for a third party with no independent audit shown — "
                 "run the scans and SHOW the evidence (or attach the audit) before saying this"))
    return hits


DETECTORS = [
    ("LAW-01", "PHONE-FIRST", "build_for_mac_and_iphone", d_phone_first,
     "Replace the Mac/Terminal paste with a phone-native path (tap, iOS Shortcut, webhook/URL) or fully automate it; if a Mac step is truly unavoidable, say so with the named reason."),
    ("LAW-02", "SHOW, DON'T INSTRUCT", "show_dont_instruct", d_show_dont_instruct,
     "Do the build→render→view chain yourself and present the finished artifact (PDF/image/live page). Strip the how-to; deliver the thing."),
    ("LAW-03", "DELIVER THE USABLE ARTIFACT", "deliver_usable_artifact", d_deliver_artifact,
     "Surface the real artifact — present the file so it opens in one tap, or deploy to a live https URL. Lead with the openable thing, not a path."),
    ("LAW-04", "TEST THE LIMIT FIRST", "test_limits_then_capture_capability", d_test_limit,
     "Attempt the obvious path (sandbox CLI, installed tool, computer-use, automation) BEFORE asserting a wall; name the exact failing step only after a real try."),
    ("LAW-05", "OPERATOR-LANGUAGE ENDING", "auto_act_never_ask", d_operator_ending,
     "End on what was done / what's next / the ONE owner-only action. Replace 'want me to?' with the done version unless it's a real carve-out. Translate analyst-speak into 'what you can say/do now'."),
    ("LAW-06", "PLAIN ENGLISH", "plain_english", d_plain_english,
     "Cut self-naming, jargon, and sycophancy. Say it plainly in the owner's register; acknowledge misses in one line and move to the fix."),
    ("LAW-07", "AUDIT BEFORE THIRD-PARTY SEND", "audit_before_third_party_send", d_third_party_send,
     "Never call a deliverable 'safe to send / send-ready / sanitized / ready for <recipient>' to anyone outside the workspace without an INDEPENDENT audit run AND shown — re-scan from scratch (secrets, PII, private data) and put the commands + hits/0-hits evidence (or the attached audit report) in the reply. A clean claim with no shown verification is the violation."),
]


def lint(text, ask=None):
    """Run every detector. Return a structured result dict."""
    scan_text = _strip_code_fences_keep_marker(text) if False else text
    findings = []
    for law_id, law_name, mem_key, fn, fix in DETECTORS:
        evidence = fn(scan_text, ask)
        if evidence:
            findings.append({
                "law_id": law_id,
                "law": law_name,
                "memory_key": mem_key,
                "fix": fix,
                "evidence": [{"matched": e[0], "note": e[1]} for e in evidence],
            })
    verdict = "REVISE" if findings else "APPROVED"
    return {
        "verdict": verdict,
        "issues_found": len(findings),
        "laws_checked": len(DETECTORS),
        "findings": findings,
    }


def human_summary(result, ask=None):
    lines = []
    v = result["verdict"]
    bar = "=" * 60
    lines.append(bar)
    if v == "APPROVED":
        lines.append(f"VERDICT: APPROVED  ✅   (deterministic gate — {result['laws_checked']} core laws clean)")
        if ask:
            lines.append(f"asked-for: {ask}")
        lines.append(bar)
        return "\n".join(lines)
    lines.append(f"VERDICT: REVISE  🚩   ({result['issues_found']} law(s) flagged)")
    if ask:
        lines.append(f"asked-for: {ask}")
    lines.append(bar)
    for i, f in enumerate(result["findings"], 1):
        lines.append(f"{i}. {f['law_id']} — {f['law']}  ({f['memory_key']})")
        for e in f["evidence"]:
            lines.append(f"     tell: \"{e['matched']}\"")
            lines.append(f"           ↳ {e['note']}")
        lines.append(f"     FIX: {f['fix']}")
        lines.append("")
    lines.append(bar)
    return "\n".join(lines)


def main():
    ap = argparse.ArgumentParser(description="Deterministic pre-reply gate for the brain.")
    src = ap.add_mutually_exclusive_group()
    src.add_argument("--file", help="path to a file containing the draft reply")
    src.add_argument("--text", help="inline draft reply text")
    ap.add_argument("--ask", help="what the owner actually asked for (sharpens LAW-02/04)")
    ap.add_argument("--json", action="store_true", help="emit JSON only")
    ap.add_argument("--log", action="store_true", help="record findings to mistake_ledger.json")
    ap.add_argument("--caught-by", default="gate",
                    help="for --log: 'gate' (linter caught it pre-send) or 'missed' (the owner caught it)")
    args = ap.parse_args()

    if args.file:
        with open(args.file, "r", encoding="utf-8") as fh:
            draft = fh.read()
    elif args.text:
        draft = args.text
    else:
        draft = sys.stdin.read()

    result = lint(draft, ask=args.ask)

    if args.log and result["findings"]:
        try:
            from ledger import record_findings  # type: ignore
        except Exception:
            sys.path.insert(0, HERE)
            from ledger import record_findings  # type: ignore
        record_findings(result["findings"], caught_by=args.caught_by)

    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print(human_summary(result, ask=args.ask))

    sys.exit(1 if result["verdict"] == "REVISE" else 0)


if __name__ == "__main__":
    main()
