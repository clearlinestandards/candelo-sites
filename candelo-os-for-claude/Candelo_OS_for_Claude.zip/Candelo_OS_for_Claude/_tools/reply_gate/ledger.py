#!/usr/bin/env python3
"""
ledger.py — recurrence counter for the reply gate.

This is what makes the gate "to standard" instead of vibes: every mistake CLASS
(one of the six core laws) gets a running count over time, split by whether the
gate CAUGHT it pre-send or it was MISSED (the owner caught it). Drift is visible — if
LAW-01 keeps recurring, the number goes up and the morning review shows it.

DATA: mistake_ledger.json (next to this file). Schema:
{
  "events": [
     {"ts": ISO8601, "law_id": "LAW-01", "law": "...", "memory_key": "...",
      "caught_by": "gate"|"missed", "matched": "<phrase>", "source": "lint|manual"}
  ]
}

COMMANDS
  # record one mistake by hand (e.g. the owner caught something the gate missed)
  python3 ledger.py add --law LAW-01 --caught-by missed --note "paste at your mac"
  # print the per-class report (counts + last-seen + caught/missed split)
  python3 ledger.py report
  # one-line digest for the morning daily-review (machine-light)
  python3 ledger.py report --daily
  # JSON report (for wiring)
  python3 ledger.py report --json

record_findings(findings, caught_by) is the function lint_reply.py calls to log
its own hits automatically when run with --log.
"""

import argparse
import datetime
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
LEDGER = os.path.join(HERE, "mistake_ledger.json")

LAW_NAMES = {
    "LAW-01": ("PHONE-FIRST", "build_for_mac_and_iphone"),
    "LAW-02": ("SHOW, DON'T INSTRUCT", "show_dont_instruct"),
    "LAW-03": ("DELIVER THE USABLE ARTIFACT", "deliver_usable_artifact"),
    "LAW-04": ("TEST THE LIMIT FIRST", "test_limits_then_capture_capability"),
    "LAW-05": ("OPERATOR-LANGUAGE ENDING", "auto_act_never_ask"),
    "LAW-06": ("PLAIN ENGLISH", "plain_english"),
}


def _now():
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def _load():
    if not os.path.exists(LEDGER):
        return {"events": []}
    try:
        with open(LEDGER, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (json.JSONDecodeError, OSError):
        return {"events": []}


def _save(data):
    with open(LEDGER, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
        fh.write("\n")


def add_event(law_id, caught_by="missed", matched="", source="manual"):
    law_id = law_id.upper()
    name, key = LAW_NAMES.get(law_id, ("UNKNOWN", "unknown"))
    data = _load()
    data["events"].append({
        "ts": _now(),
        "law_id": law_id,
        "law": name,
        "memory_key": key,
        "caught_by": caught_by,
        "matched": matched[:120],
        "source": source,
    })
    _save(data)
    return law_id, name


def record_findings(findings, caught_by="gate"):
    """Called by lint_reply.py --log. One event per law flagged."""
    for f in findings:
        ev = f.get("evidence", [{}])
        matched = ev[0].get("matched", "") if ev else ""
        add_event(f["law_id"], caught_by=caught_by, matched=matched, source="lint")


def _aggregate(events):
    classes = {}
    for lid, (name, key) in LAW_NAMES.items():
        classes[lid] = {"law": name, "memory_key": key,
                        "total": 0, "gate": 0, "missed": 0, "last_seen": None}
    for e in events:
        lid = e["law_id"]
        if lid not in classes:
            classes[lid] = {"law": e.get("law", "UNKNOWN"),
                            "memory_key": e.get("memory_key", "unknown"),
                            "total": 0, "gate": 0, "missed": 0, "last_seen": None}
        c = classes[lid]
        c["total"] += 1
        if e["caught_by"] == "gate":
            c["gate"] += 1
        else:
            c["missed"] += 1
        if c["last_seen"] is None or e["ts"] > c["last_seen"]:
            c["last_seen"] = e["ts"]
    return classes


def report_text(data):
    events = data["events"]
    classes = _aggregate(events)
    total = len(events)
    missed = sum(1 for e in events if e["caught_by"] == "missed")
    caught = total - missed
    lines = []
    lines.append("REPLY-GATE RECURRENCE LEDGER")
    lines.append("=" * 56)
    lines.append(f"total mistakes logged: {total}   |   gate-caught: {caught}   |   missed (the owner caught): {missed}")
    lines.append("-" * 56)
    lines.append(f"{'LAW':8} {'total':>5} {'gate':>5} {'miss':>5}  last-seen   class")
    for lid in sorted(classes):
        c = classes[lid]
        last = (c["last_seen"][:10] if c["last_seen"] else "  —  ")
        flag = " ⚠" if c["missed"] > 0 else ""
        lines.append(f"{lid:8} {c['total']:>5} {c['gate']:>5} {c['missed']:>5}  {last}  {c['law']}{flag}")
    lines.append("=" * 56)
    # drift signal: any class with rising misses
    worst = sorted(classes.items(), key=lambda kv: kv[1]["missed"], reverse=True)
    if worst and worst[0][1]["missed"] > 0:
        lid, c = worst[0]
        lines.append(f"DRIFT WATCH: {lid} ({c['law']}) has been MISSED {c['missed']}x — "
                     f"the gate isn't catching it. Tighten the {lid} detector in lint_reply.py.")
    else:
        lines.append("DRIFT WATCH: no misses on record — every logged mistake was caught pre-send. ✅")
    return "\n".join(lines)


def report_daily_line(data):
    """One compact line for the morning daily-review."""
    events = data["events"]
    classes = _aggregate(events)
    total = len(events)
    missed = sum(1 for e in events if e["caught_by"] == "missed")
    if total == 0:
        return "Reply-gate ledger: 0 mistakes logged — clean. ✅"
    # name the worst recurring class
    worst = max(classes.items(), key=lambda kv: kv[1]["total"])
    lid, c = worst
    tag = ""
    if c["total"] > 0:
        tag = f" Top class: {lid} {c['law']} ({c['total']}x, {c['missed']} missed)."
    return (f"Reply-gate ledger: {total} mistakes logged, {missed} missed (the owner caught), "
            f"{total - missed} caught by the gate.{tag}")


def main():
    ap = argparse.ArgumentParser(description="Reply-gate recurrence counter.")
    sub = ap.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("add", help="record one mistake")
    a.add_argument("--law", required=True, help="LAW-01 .. LAW-06")
    a.add_argument("--caught-by", default="missed", choices=["gate", "missed"])
    a.add_argument("--note", default="", help="the matched phrase / context")

    r = sub.add_parser("report", help="print recurrence report")
    r.add_argument("--daily", action="store_true", help="one-line morning digest")
    r.add_argument("--json", action="store_true", help="machine-readable")

    args = ap.parse_args()

    if args.cmd == "add":
        lid, name = add_event(args.law, caught_by=args.caught_by, matched=args.note, source="manual")
        print(f"logged {lid} ({name}) caught_by={args.caught_by}")
        return

    data = _load()
    if args.cmd == "report":
        if args.json:
            print(json.dumps({"classes": _aggregate(data["events"]),
                              "total": len(data["events"])}, indent=2))
        elif args.daily:
            print(report_daily_line(data))
        else:
            print(report_text(data))


if __name__ == "__main__":
    main()
