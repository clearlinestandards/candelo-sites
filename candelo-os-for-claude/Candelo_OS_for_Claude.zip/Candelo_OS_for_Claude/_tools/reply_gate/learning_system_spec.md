---
name: Learning System Spec — the 6-level enforcement stack
description: How an assistant actually LEARNS — not "capture a law to a file," but recall-and-enforce at the moment of action. Six levels from retrieval to fine-tune, marking what this kit ships now vs what is a staged, optional extension. The same engine that makes a reply gate worth trusting.
type: methodology
status: living
---

# The Learning System — 6-level stack

The core insight: **capturing a "law" into your notes is not learning.** A markdown file is inert.
The assistant can read it, nod, and still ship the same mistake an hour later — because the failure
is not *missing knowledge*, it's *failure to recall and enforce the rule at the exact moment of
acting*. On background tasks this is worst: there's no hook, nothing forces a check, so the only
thing standing between a known law and a repeat violation is whether the assistant happens to
remember it.

So "learning" here is an **engineering problem of enforcement**, not a knowledge problem. The stack
below is six levels, weakest to strongest. Levels 2, 4, and 5 are what this kit ships. Levels 1 and 3
are conventions it assumes your brain already provides in some form; Level 6 is a staged, optional
extension.

```
 ┌─────────────────────────────────────────────────────────────────────┐
 │  L6  FINE-TUNE / DISTILL   — bake stable patterns into the weights   │  STAGED (optional)
 │  L5  CONSOLIDATION         — squeeze sprawl into the load-bearing set │  SHIPS (core_laws.md)
 │  L4  EVAL / RECURRENCE LOOP — count each mistake-class over time      │  SHIPS (ledger.py)
 │  L3  DRIFT DETECTOR        — catch canon values going stale          │  CONVENTION
 │  L2  ENFORCED PRE-ACTION GATE — deterministic lint before send       │  SHIPS (lint_reply.py)
 │  L1  RETRIEVAL (RAG)       — the brain + search surface the law       │  CONVENTION
 └─────────────────────────────────────────────────────────────────────┘
```

---

## L1 — RETRIEVAL (RAG). *Convention your brain provides.*

Surface the relevant law at the right moment. This is your brain folder + an always-current
`_STATE.md` digest + whatever search/pre-tool hook your setup uses. It answers "what does my canon
say about X." **Its limit is exactly the diagnosis above:** retrieval makes the law *available*, it
does not make it *binding*. A law you can look up is not a law the assistant will obey under time
pressure. RAG is necessary and not sufficient.

## L2 — ENFORCED PRE-ACTION GATE. *Ships — `lint_reply.py`.*

A deterministic linter that scans the DRAFT reply for the textual signatures of the six core laws
**before it's sent**, and returns APPROVED or REVISE with the exact law + fix. Regex + heuristics,
$0, standard library only, runs identically on every surface. This is the level that converts a
*known* law into a *blocked* violation. Unlike RAG it does not depend on the assistant remembering —
the signature match is mechanical.

- Spec of what it enforces: `core_laws.md` (six laws, each with its detectable tell).
- Honest limit: on a background task nothing *forces* the gate to be invoked (no hook engine off the
  main CLI). So realistic enforcement is the gate + a self-invoke discipline before any consequential
  reply, with L4's counter making a skipped gate visible after the fact. Named plainly so it isn't
  oversold.

## L3 — DRIFT DETECTOR. *Convention — a separate scanner if your canon has versioned values.*

Catches a *different* failure class than L2: not "I broke a behavior law" but "I repeated a canon
VALUE that has gone stale" (e.g. an old vendor name after you switched vendors, an old price after
you changed pricing, an old domain after you migrated). L2 watches behavior; L3 watches facts. Both
are deterministic scanners; they compose. This kit ships the behavior gate (L2); a value-drift
scanner is easy to add the same way if your brain tracks canon values that change.

## L4 — EVAL / RECURRENCE LOOP. *Ships — `ledger.py` + `mistake_ledger.json`.*

This is what makes the system **"to standard" instead of vibes.** Every mistake-class (the six laws)
gets a running count over time, split by whether the gate CAUGHT it pre-send (`gate`) or it was
MISSED and you caught it (`missed`). The per-class report exposes drift: if LAW-01 keeps getting
missed, the number climbs and the morning digest line shows it, which says to tighten that detector.
Without this level the gate is unfalsifiable — you can't tell if it's working. With it, "is the
assistant actually learning?" becomes a number that should trend down.

- `python3 ledger.py report` — full per-class table.
- `python3 ledger.py report --daily` — one line, suitable for an overnight digest so it surfaces every morning.
- `lint_reply.py --log` auto-records gate catches; `ledger.py add --law LAW-0X --caught-by missed` records what you catch.

## L5 — CONSOLIDATION. *Ships — `core_laws.md`.*

A sprawling feedback set (it's easy to grow to 30+ rule files) is the enemy of enforcement, because
a gate with 30 fuzzy detectors gets ignored. Consolidation squeezes the set down to the **six
load-bearing, behavior-changing laws that fire on every reply**, each with a single detectable
signature. Keep any long-form rule write-ups as reference; `core_laws.md` is the enforcement spec.
New laws get added only when a miss *recurs* (errors-to-systems), never on first sight. Signal over
volume.

## L6 — FINE-TUNE / DISTILL. *Staged — optional, not built by this kit.*

The strongest level: once a pattern is **stable** (a law's miss-rate has been near-zero for a
sustained window, and its signatures are well-characterized by L4's data), bake it into the model
weights so the behavior is the default output, not a post-hoc catch. This is the difference between
"I correct myself at the gate every time" and "I no longer draft the violation in the first place."

**A concrete $0, fully local path (only if you run a local model):**

1. **Harvest the dataset from L4.** The mistake ledger is the training corpus seed. Each event is
   `(draft snippet that violated LAW-X, the law, the fix)`. Pair every flagged draft (the "before")
   with its corrected version (the "after") — that's a preference/SFT pair. APPROVED drafts are
   positive examples; REVISE drafts + their fixes are the contrastive pairs. Aim for a few hundred
   pairs before training — the ledger accumulates them automatically as the gate runs.
2. **Base model: a local model you already run** (any small open model via Ollama, for example). No
   API, no cost, nothing leaves your machine.
3. **Method: LoRA / QLoRA** (low-rank adapters) so training fits in a typical machine's memory and
   the base weights are untouched — train an adapter, not the whole model. Tooling such as `unsloth`
   or `axolotl` for the run; export to **GGUF** and load the adapter into **Ollama** via a
   `Modelfile` (`ADAPTER ./laws.gguf`). All local.
4. **What to distill first:** the laws with the highest, most stable signal in L4 — typically the
   ones with the cleanest signatures and the most history (e.g. phone-first and operator-ending).
   Leave fuzzy/contextual laws (like show-don't-instruct, which needs to know what was asked) at the
   gate level — they're harder to bake and the gate handles them.
5. **Keep the gate even after fine-tuning.** L6 lowers the violation rate at generation time; L2
   stays as the safety net for the residual. Belt and suspenders, not either/or. L4 keeps counting so
   you can SEE the fine-tune working (miss-rate drop after the adapter ships).
6. **Trigger to actually do it:** when L4 shows a law's pattern is stable and the dataset has enough
   pairs. Until then, fine-tuning would just bake in noise — the gate + counter are the right tool
   while patterns are still being characterized. Deliberately staged, not skipped.

---

## Why the loop matters

A system that records every correction, enforces it deterministically the next time, and counts its
own error rate down is fundamentally different from one that resets each session and re-hits the same
wall. The corrections become *your* `core_laws.md` + ledger + (eventually) adapter — a standard that
gets sharper with use instead of evaporating. The product isn't the model; it's the model that
learns your standards and proves it with a falling number.
