#!/usr/bin/env python3
"""
semantic_search.py — Bulletproof Brain READ-side: $0 semantic retrieval.

The brain-first hook does a literal-keyword grep. That misses when the owner doesn't
guess the exact word ("the 711 thing" never matches `two_store_711`). This adds
a meaning-based fallback using the **local Ollama embeddings already on the Mac
mini** — zero out-of-pocket, never leaves the machine.

Granularity = one vector per markdown FILE (title + first ~300 words). A query
then resolves straight to "which file answers this," which is exactly what a
retrieval layer should return.

Two entry points:
  build_index(root)         -> embeds changed files, caches to .semantic_index.json
  search(query, root, k)    -> returns [(score, relpath, title), ...] top-k

Designed to be imported by brain_first_search.py inside a try/except: if Ollama
is down, the model is missing, or the index is empty, every call returns [] and
the caller falls back to keyword search. It NEVER raises to the caller.

Standalone:
  python3 semantic_search.py --build [--root R] [--max N]
  python3 semantic_search.py --query "the 711 thing" [--k 6]
"""

import os
import re
import sys
import json
import math
import time
import hashlib
import urllib.request

OLLAMA_URL = os.environ.get("OLLAMA_URL", "http://localhost:11434")
EMBED_MODEL = os.environ.get("EMBED_MODEL", "nomic-embed-text")
INDEX_NAME = ".semantic_index.json"
SKIP = ("graphify-out", "node_modules", ".git", "_canon_backup",
        "__pycache__", "bulletproof_brain/backups", "Research/local_")
MAX_FILE_BYTES = 600_000

def _root_default():
    env = os.environ.get("BRAIN_ROOT")
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

def _index_path():
    return os.path.join(os.path.dirname(__file__), INDEX_NAME)

# --------------------------------------------------------------------------- #
# Ollama embedding (never raises; returns None on any failure)
# --------------------------------------------------------------------------- #
def embed(text):
    try:
        body = json.dumps({"model": EMBED_MODEL, "prompt": text[:4000]}).encode()
        req = urllib.request.Request(OLLAMA_URL + "/api/embeddings", data=body,
                                     headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(req, timeout=20) as r:
            data = json.loads(r.read().decode())
        v = data.get("embedding")
        if isinstance(v, list) and v:
            return v
    except Exception:
        return None
    return None

def ollama_up():
    try:
        with urllib.request.urlopen(OLLAMA_URL + "/api/tags", timeout=4) as r:
            return r.status == 200
    except Exception:
        return False

# --------------------------------------------------------------------------- #
def _file_text(path):
    try:
        if os.path.getsize(path) > MAX_FILE_BYTES:
            return None
        with open(path, "r", encoding="utf-8", errors="ignore") as fh:
            raw = fh.read()
    except OSError:
        return None
    # title: frontmatter title -> first heading -> filename
    title = ""
    mt = re.search(r"^title:\s*(.+)$", raw, re.MULTILINE)
    if mt:
        title = mt.group(1).strip()
    if not title:
        mh = re.search(r"^#\s+(.+)$", raw, re.MULTILINE)
        if mh:
            title = mh.group(1).strip()
    if not title:
        title = os.path.splitext(os.path.basename(path))[0]
    # body: strip frontmatter + markdown punctuation, first ~300 words
    body = re.sub(r"^---.*?---", "", raw, count=1, flags=re.DOTALL)
    body = re.sub(r"[#>*`|_\-]+", " ", body)
    body = re.sub(r"\s+", " ", body).strip()
    words = body.split()[:300]
    return title, title + ". " + " ".join(words)

def _iter_md(root):
    for dp, dn, fn in os.walk(root):
        if any(s in dp for s in SKIP):
            dn[:] = []
            continue
        for f in fn:
            if f.endswith(".md"):
                yield os.path.join(dp, f)

def build_index(root=None, max_files=None, verbose=True):
    """Embed changed/new markdown files; reuse cached vectors for unchanged
    ones (keyed by path+mtime hash). Returns (indexed, skipped, ok)."""
    root = root or _root_default()
    if not ollama_up():
        if verbose:
            print("semantic: Ollama not reachable — skipping index build (keyword search still works).")
        return (0, 0, False)
    old = {}
    try:
        with open(_index_path(), "r", encoding="utf-8") as fh:
            for e in json.load(fh).get("entries", []):
                old[e["path"]] = e
    except Exception:
        old = {}
    entries = []
    indexed = skipped = 0
    for path in _iter_md(root):
        rel = os.path.relpath(path, root)
        try:
            mt = os.path.getmtime(path)
        except OSError:
            continue
        sig = hashlib.md5(f"{rel}:{mt}".encode()).hexdigest()
        prev = old.get(rel)
        if prev and prev.get("sig") == sig and prev.get("vec"):
            entries.append(prev)
            skipped += 1
            continue
        ft = _file_text(path)
        if not ft:
            continue
        title, text = ft
        vec = embed(text)
        if not vec:
            continue
        entries.append({"path": rel, "title": title[:160], "sig": sig, "vec": vec})
        indexed += 1
        if max_files and indexed >= max_files:
            break
    try:
        with open(_index_path(), "w", encoding="utf-8") as fh:
            json.dump({"model": EMBED_MODEL, "built": time.time(), "entries": entries}, fh)
    except OSError:
        return (indexed, skipped, False)
    if verbose:
        print(f"semantic: index built — {indexed} embedded, {skipped} reused, {len(entries)} total.")
    return (indexed, skipped, True)

def _cos(a, b):
    s = da = db = 0.0
    for x, y in zip(a, b):
        s += x * y; da += x * x; db += y * y
    if da == 0 or db == 0:
        return 0.0
    return s / (math.sqrt(da) * math.sqrt(db))

def search(query, root=None, k=6):
    """Return [(score, relpath, title)] top-k. [] on any failure (caller falls
    back to keyword search)."""
    try:
        with open(_index_path(), "r", encoding="utf-8") as fh:
            idx = json.load(fh)
        entries = idx.get("entries", [])
        if not entries:
            return []
        qv = embed(query)
        if not qv:
            return []
        scored = []
        for e in entries:
            v = e.get("vec")
            if v and len(v) == len(qv):
                scored.append((_cos(qv, v), e["path"], e.get("title", "")))
        scored.sort(key=lambda x: -x[0])
        # only return reasonably-similar hits
        return [s for s in scored[:k] if s[0] > 0.35]
    except Exception:
        return []

def main():
    root = _root_default()
    for i, a in enumerate(sys.argv):
        if a == "--root" and i + 1 < len(sys.argv):
            root = os.path.abspath(sys.argv[i + 1])
    if "--build" in sys.argv:
        mx = None
        for i, a in enumerate(sys.argv):
            if a == "--max" and i + 1 < len(sys.argv):
                mx = int(sys.argv[i + 1])
        build_index(root, max_files=mx)
    elif "--query" in sys.argv:
        i = sys.argv.index("--query")
        q = sys.argv[i + 1] if i + 1 < len(sys.argv) else ""
        k = 6
        if "--k" in sys.argv:
            k = int(sys.argv[sys.argv.index("--k") + 1])
        for score, path, title in search(q, root, k):
            print(f"{score:.3f}  {path}  — {title}")
    else:
        print(__doc__)

if __name__ == "__main__":
    main()
