#!/usr/bin/env python3
"""
sidecar.py — Bulletproof Brain CAPTURE-side: make non-text outputs readable.

Graphify (and the brain-first search) can only read text. Videos, spreadsheets,
and PDFs are blind spots — the rendered .mp4 faceless drafts and the _TWO_STORE
.xlsx are exactly why Claude Code "didn't know" about the 711 outputs.

This walks the brain folder for binary deliverables and writes a markdown
SIDECAR next to each one (`<name>.<ext>.sidecar.md`) containing a transcript /
summary PLUS a pointer to the real binary path. The sidecar is markdown, so it
lands in the brain and every surface can read it — the binary stays put.

Formats:
  .mp4/.mov/.m4a/.mp3/.wav  -> transcript via _tools/video_transcribe/transcribe.sh
                               (local Whisper, $0). Falls back to a pointer-only
                               note if the transcriber/ffmpeg isn't available.
  .xlsx/.xls                 -> sheet names + headers + a few sample rows
                               (openpyxl if present; pointer-only otherwise).
  .pdf                       -> first ~3000 chars of text (pdftotext or
                               pypdf if present; pointer-only otherwise).

Idempotent: skips a binary whose sidecar already exists and is newer than it.
Never raises: any per-file failure is logged and skipped.

Usage:
  python3 sidecar.py [--root <brain root>] [--limit N] [--dry-run]
"""

import os
import re
import sys
import subprocess
import datetime

def find_root():
    for i, a in enumerate(sys.argv):
        if a == "--root" and i + 1 < len(sys.argv):
            return os.path.abspath(sys.argv[i + 1])
    env = os.environ.get("BRAIN_ROOT")
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

ROOT = find_root()
DRY = "--dry-run" in sys.argv
LIMIT = None
for i, a in enumerate(sys.argv):
    if a == "--limit" and i + 1 < len(sys.argv):
        LIMIT = int(sys.argv[i + 1])

VIDEO_AUDIO = (".mp4", ".mov", ".m4a", ".mp3", ".wav", ".webm", ".m4v")
SHEETS = (".xlsx", ".xls")
PDFS = (".pdf",)
ALL_EXT = VIDEO_AUDIO + SHEETS + PDFS

# Dirs we never descend into (noise / backups / the transcriber's own outputs).
SKIP = ("graphify-out", "node_modules", ".git", "_canon_backup",
        "__pycache__", "bulletproof_brain/backups")

SIDECAR_SUFFIX = ".sidecar.md"

def log(msg):
    line = f"[{datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] sidecar: {msg}"
    print(line)
    try:
        with open(os.path.join(os.path.dirname(__file__), "state.log"), "a", encoding="utf-8") as fh:
            fh.write(line + "\n")
    except OSError:
        pass

def needs_sidecar(binpath):
    side = binpath + SIDECAR_SUFFIX
    if not os.path.exists(side):
        return True
    # Self-heal: if the existing sidecar was a degraded pointer-only fallback
    # (e.g. written where Whisper/pdftotext wasn't available), regenerate it so
    # a later run on a fully-equipped machine upgrades it to a real transcript.
    try:
        with open(side, "r", encoding="utf-8", errors="ignore") as fh:
            head = fh.read(400)
        if "capture_quality: pointer-only" in head:
            return True
    except OSError:
        return True
    try:
        return os.path.getmtime(side) < os.path.getmtime(binpath)
    except OSError:
        return True

def is_degraded(body):
    """True if the extractor couldn't read the binary and fell back to a
    pointer-only note (so a later run on a better-equipped box should retry)."""
    markers = ("pointer only", "not installed", "not available",
               "timed out", "failed", "no clean transcript")
    b = body.lower()
    return any(m in b for m in markers)

def frontmatter(binrel, kind, quality):
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    return (
        "---\n"
        f"title: Sidecar — {os.path.basename(binrel)}\n"
        f"type: non-text capture sidecar ({kind})\n"
        f"source_binary: {binrel}\n"
        f"capture_quality: {quality}\n"
        f"generated: {now} by _tools/bulletproof_brain/sidecar.py\n"
        "note: This markdown stands in for a binary the brain can't read directly. "
        "The real file is at the source_binary path above.\n"
        "---\n\n"
        f"# {os.path.basename(binrel)} — readable sidecar\n\n"
        f"Real file (not readable by the graph): `{binrel}`\n\n"
    )

# --------------------------------------------------------------------------- #
# Per-format extractors (each returns body text, never raises)
# --------------------------------------------------------------------------- #
def transcribe_av(binpath, binrel):
    script = os.path.join(ROOT, "_tools", "video_transcribe", "transcribe.sh")
    if not os.path.exists(script):
        return "_Transcriber not installed (`_tools/video_transcribe/transcribe.sh` missing) — pointer only._\n"
    if DRY:
        return "_(dry-run: would transcribe)_\n"
    try:
        # transcribe.sh writes a *_clean.txt; capture its stdout path or read transcripts dir
        out = subprocess.run(["bash", script, binpath], cwd=ROOT,
                             capture_output=True, text=True, timeout=900)
        # try to find the produced clean transcript
        tdir = os.path.join(ROOT, "_tools", "video_transcribe", "transcripts")
        best = ""
        if os.path.isdir(tdir):
            cands = [os.path.join(tdir, f) for f in os.listdir(tdir) if f.endswith("_clean.txt")]
            if cands:
                best = max(cands, key=os.path.getmtime)
        if best and os.path.exists(best):
            with open(best, "r", encoding="utf-8", errors="ignore") as fh:
                txt = fh.read().strip()
            return "## Transcript\n\n" + txt[:6000] + ("\n\n_(truncated)_\n" if len(txt) > 6000 else "\n")
        return "## Transcript\n\n_Transcriber ran but no clean transcript found._\n\n```\n" + (out.stdout or out.stderr)[:600] + "\n```\n"
    except subprocess.TimeoutExpired:
        return "_Transcription timed out (long file) — pointer only; run transcribe.sh manually._\n"
    except Exception as e:
        return f"_Transcription failed ({e}) — pointer only._\n"

def summarize_sheet(binpath):
    try:
        import openpyxl  # noqa
    except Exception:
        return "_openpyxl not installed — pointer only. `pip install openpyxl --break-system-packages` to enable sheet summaries._\n"
    if DRY:
        return "_(dry-run: would summarize sheet)_\n"
    try:
        import openpyxl
        wb = openpyxl.load_workbook(binpath, read_only=True, data_only=True)
        out = []
        for ws in wb.worksheets[:6]:
            out.append(f"### Sheet: {ws.title}  ({ws.max_row} rows × {ws.max_column} cols)")
            rows = []
            for r in ws.iter_rows(max_row=6, values_only=True):
                cells = [str(c) for c in r if c is not None]
                if cells:
                    rows.append(" | ".join(cells)[:200])
            out.append("```\n" + "\n".join(rows) + "\n```")
        return "## Spreadsheet summary\n\n" + "\n\n".join(out) + "\n"
    except Exception as e:
        return f"_Sheet read failed ({e}) — pointer only._\n"

def summarize_pdf(binpath):
    if DRY:
        return "_(dry-run: would extract pdf text)_\n"
    # try pdftotext first (fast, common on macOS via poppler), then pypdf
    try:
        out = subprocess.run(["pdftotext", "-l", "5", binpath, "-"],
                             capture_output=True, text=True, timeout=120)
        if out.returncode == 0 and out.stdout.strip():
            txt = re.sub(r"\n{3,}", "\n\n", out.stdout).strip()
            return "## PDF text (first pages)\n\n" + txt[:3000] + ("\n\n_(truncated)_\n" if len(txt) > 3000 else "\n")
    except Exception:
        pass
    try:
        import pypdf
        r = pypdf.PdfReader(binpath)
        txt = ""
        for pg in r.pages[:5]:
            txt += pg.extract_text() or ""
        txt = txt.strip()
        if txt:
            return "## PDF text (first pages)\n\n" + txt[:3000] + ("\n\n_(truncated)_\n" if len(txt) > 3000 else "\n")
    except Exception:
        pass
    return "_No PDF text extractor available (need `pdftotext` or `pypdf`) — pointer only._\n"

# --------------------------------------------------------------------------- #
def process(binpath):
    binrel = os.path.relpath(binpath, ROOT)
    ext = os.path.splitext(binpath)[1].lower()
    if ext in VIDEO_AUDIO:
        kind, body = "video/audio transcript", transcribe_av(binpath, binrel)
    elif ext in SHEETS:
        kind, body = "spreadsheet summary", summarize_sheet(binpath)
    elif ext in PDFS:
        kind, body = "pdf text", summarize_pdf(binpath)
    else:
        return False
    quality = "pointer-only" if is_degraded(body) else "extracted"
    content = frontmatter(binrel, kind, quality) + body
    side = binpath + SIDECAR_SUFFIX
    if DRY:
        log(f"DRY would write {os.path.relpath(side, ROOT)}")
        return True
    try:
        with open(side, "w", encoding="utf-8") as fh:
            fh.write(content)
        log(f"wrote {os.path.relpath(side, ROOT)}")
        return True
    except OSError as e:
        log(f"FAILED writing sidecar for {binrel}: {e}")
        return False

def main():
    found = 0
    done = 0
    for dp, dn, fn in os.walk(ROOT):
        if any(s in dp for s in SKIP):
            dn[:] = []   # prune
            continue
        for f in fn:
            if f.endswith(SIDECAR_SUFFIX):
                continue
            ext = os.path.splitext(f)[1].lower()
            if ext not in ALL_EXT:
                continue
            binpath = os.path.join(dp, f)
            found += 1
            if not needs_sidecar(binpath):
                continue
            if process(binpath):
                done += 1
            if LIMIT and done >= LIMIT:
                log(f"hit --limit {LIMIT}, stopping")
                log(f"done: {done} sidecars written, {found} binaries scanned")
                return
    log(f"done: {done} sidecars written/updated, {found} binaries scanned")

if __name__ == "__main__":
    main()
