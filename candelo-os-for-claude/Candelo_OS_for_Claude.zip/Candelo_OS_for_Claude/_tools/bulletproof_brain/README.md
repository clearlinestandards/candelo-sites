# bulletproof_brain — the brain that stays current on its own

Two jobs: **capture** ("if it happened, it's in the brain") and **retrieval** ("anywhere I go,
every Claude just reads the brain and has the big picture"). Everything here is **$0 and local** —
no API key, no model bill. It deliberately does not run a billed headless model on a schedule; the
graph reindex stays a free local step.

## What it does

**READ side**
- `gen_state.py` regenerates **`_STATE.md`** at your brain root: a ~3 KB always-current "big
  picture" (projects + status, recent decisions, open items, what's pending the graph, pointer
  index). Deterministic and extractive — it pulls real lines from your files, no model call. This
  is the layer loaded first on every surface. **Describe your projects in `projects.json`.**
- `semantic_search.py` — meaning-based search over your markdown files using **local Ollama
  embeddings** (one vector per file). Degrades to a no-op if Ollama isn't installed; keyword search
  still works.

**CAPTURE side**
- `sidecar.py` turns every video/audio file into a transcript note, every spreadsheet into a
  summary, and every PDF into extracted text — written as `<file>.sidecar.md` next to the original,
  so the brain "knows" those files exist.
- `auto_update.sh` is the orchestrator the background agent runs: nightly = a full pass (state +
  sidecars + search index + free graph reindex + optional mirror); on file-change = a light pass
  (state only). One script decides which, so cost stays bounded.
- `com.portablebrain.autoupdate.plist` fires `auto_update.sh` nightly and on file-change (debounced).

## Install / uninstall

```bash
export BRAIN_ROOT="$HOME/Documents/Claude/Projects/my-brain"   # your brain folder
bash "$BRAIN_ROOT/_tools/bulletproof_brain/install_bulletproof_brain.sh"
```

The installer sets up the background agent (with your paths baked in), runs a first full pass, and
self-tests every component PASS/FAIL. Undo with `uninstall_bulletproof_brain.sh`.

## Configure

`projects.json` is the only file you edit. List your projects, point each at its status file, and
optionally name a flagship-assets registry, a change log, and a pointer index. Missing files
degrade to "(not found)" — nothing crashes.

## Files
- `gen_state.py`, `sidecar.py`, `semantic_search.py`, `auto_update.sh` — the workers.
- `projects.json` — your config (the one file to edit).
- `com.portablebrain.autoupdate.plist` — the background agent.
- `install_*.sh` / `uninstall_*.sh` — one-command install + reversal.
- `auto_update.env` — optional; opt into the billed headless reindex (off by default).

## The two physical things only you can do
1. **Full Disk Access** for the background agent's `/bin/bash` (System Settings → Privacy &
   Security → Full Disk Access) — only needed for the optional Drive/iCloud mirror.
2. **Local Ollama** (optional) — install it for meaning-based search; without it, keyword search
   covers you.

## Note on the optional mirror
`auto_update.sh` looks for a Drive-mirror script to sync the brain to your phone. That script is
**not** included in this kit (it's specific to one person's Drive). Without it, the auto-updater
just skips that step and logs it — everything else works. Wire your own sync (Drive, iCloud,
Dropbox) if you want phone access to the files.
