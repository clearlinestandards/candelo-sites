#!/bin/bash
# ==============================================================================
# uninstall_bulletproof_brain.sh — full reversal
# ==============================================================================
# Undoes everything install_bulletproof_brain.sh + the build did:
#   1. unloads + removes the com.portablebrain.autoupdate LaunchAgent
#   2. restores the 3 edited files from the newest backup in backups/
#      (session_start_orient.sh, brain_first_search.py, CLAUDE.md)
#   3. leaves _STATE.md + the *.sidecar.md notes in place by default (they are
#      harmless captured content); pass --purge to also remove them.
# The .graphifyignore edit is left in place (additive, harmless); revert by hand
# from backups if desired.
# ==============================================================================
set -uo pipefail

ROOT="${BRAIN_ROOT:-__BRAIN_ROOT__}"
if [ "$ROOT" = "__BRAIN_ROOT__" ] || [ ! -d "$ROOT" ]; then
  echo "ERROR: BRAIN_ROOT is not set to a real folder."
  echo "  Set it to YOUR brain workspace, then re-run, e.g.:"
  echo "    export BRAIN_ROOT=\"$HOME/Documents/Claude/Projects/your-brain\""
  exit 1
fi
TOOLS="$ROOT/_tools/bulletproof_brain"
BK="$TOOLS/backups"
PLIST="com.portablebrain.autoupdate.plist"
PLIST_DST="$HOME/Library/LaunchAgents/$PLIST"
PURGE=0; [ "${1:-}" = "--purge" ] && PURGE=1

echo "Bulletproof Brain — uninstall"

# 1. LaunchAgent
if launchctl list 2>/dev/null | grep -q com.portablebrain.autoupdate; then
  launchctl unload "$PLIST_DST" 2>/dev/null && echo "  unloaded LaunchAgent" || echo "  (unload returned nonzero)"
fi
[ -f "$PLIST_DST" ] && rm -f "$PLIST_DST" && echo "  removed $PLIST_DST"

# 2. restore edited files from newest backup
restore(){
  local name="$1" dest="$2"
  local newest
  newest=$(ls -t "$BK/$name".bak_* 2>/dev/null | head -1)
  if [ -n "$newest" ]; then
    cp "$newest" "$dest" && echo "  restored $dest  (from $(basename "$newest"))"
  else
    echo "  ⚠ no backup found for $name — left as-is"
  fi
}
restore "session_start_orient.sh" "$ROOT/.claude/hooks/session_start_orient.sh"
restore "brain_first_search.py"   "$ROOT/.claude/hooks/brain_first_search.py"
restore "CLAUDE.md"               "$ROOT/CLAUDE.md"

# 3. optional purge of generated content
if [ "$PURGE" -eq 1 ]; then
  rm -f "$ROOT/_STATE.md" && echo "  removed _STATE.md"
  find "$ROOT" -name "*.sidecar.md" -not -path "*/backups/*" -delete 2>/dev/null && echo "  removed *.sidecar.md notes"
  rm -f "$TOOLS/.semantic_index.json" && echo "  removed semantic index"
fi

echo "Uninstall complete. (Hooks revert on the next Claude Code session; CLAUDE.md is restored now.)"
echo "Note: .graphifyignore _tools re-include edit left in place (harmless). Revert from $BK if you want it gone."
exit 0
