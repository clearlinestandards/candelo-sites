#!/bin/bash
# ==============================================================================
# install_bulletproof_brain.sh — one-paste installer + self-test
# ==============================================================================
# Installs the Bulletproof Brain capture+read system on the owner's Mac:
#   1. makes scripts executable
#   2. verifies the hook + CLAUDE.md edits are in place (they ship in the brain
#      folder; this confirms them and reports the backups)
#   3. installs + loads the com.portablebrain.autoupdate LaunchAgent
#   4. runs the first FULL pass (gen_state + sidecar + semantic + mirror)
#   5. SELF-TESTS every component, printing PASS/FAIL, then prints the
#      _STATE.md preview.
# Everything is $0/local. Reverse with uninstall_bulletproof_brain.sh.
# ==============================================================================
set -uo pipefail

ROOT="${BRAIN_ROOT:-__BRAIN_ROOT__}"
if [ "$ROOT" = "__BRAIN_ROOT__" ] || [ ! -d "$ROOT" ]; then
  echo "ERROR: BRAIN_ROOT is not set to a real folder."
  echo "  Set it to YOUR brain workspace, then re-run, e.g.:"
  echo "    export BRAIN_ROOT=\"$HOME/Documents/Claude/Projects/your-brain\""
  exit 1
fi
TOOLS="$ROOT/_tools/bulletproof_brain"
PLIST="com.portablebrain.autoupdate.plist"
PLIST_SRC="$TOOLS/$PLIST"
PLIST_DST="$HOME/Library/LaunchAgents/$PLIST"
PY="$(command -v python3 || echo /usr/bin/python3)"
PASS=0; FAIL=0; WARN=0
ok(){ echo "  ✓ PASS — $*"; PASS=$((PASS+1)); }
no(){ echo "  ✗ FAIL — $*"; FAIL=$((FAIL+1)); }
warn(){ echo "  ⚠ WARN — $*"; WARN=$((WARN+1)); }

echo "============================================================"
echo "Bulletproof Brain — installer + self-test"
echo "Root: $ROOT"
echo "============================================================"

# --- 1. executables -----------------------------------------------------------
echo "[1/5] chmod +x scripts..."
chmod +x "$TOOLS"/*.sh 2>/dev/null || true
echo "  done."

# --- 2. confirm edits in place ------------------------------------------------
echo "[2/5] Verifying hook + CLAUDE.md edits..."
grep -q "is_substantive" "$ROOT/.claude/hooks/brain_first_search.py" 2>/dev/null && ok "brain_first_search.py gate present (optional)" || warn "brain_first_search.py hook not present (optional — only used with Claude Code hooks)"
grep -q "_STATE.md" "$ROOT/.claude/hooks/session_start_orient.sh" 2>/dev/null && ok "session_start_orient.sh injects _STATE.md (optional)" || warn "session_start_orient.sh hook not present (optional — Claude Code only)"
grep -q "_STATE.md" "$ROOT/CLAUDE.md" 2>/dev/null && ok "CLAUDE.md references _STATE.md" || warn "CLAUDE.md does not reference _STATE.md yet (copy the kit CLAUDE.md into your brain root)"
echo "  backups are in: $TOOLS/backups/"

# --- 3. LaunchAgent -----------------------------------------------------------
echo "[3/5] Installing LaunchAgent..."
mkdir -p "$HOME/Library/LaunchAgents"
launchctl list 2>/dev/null | grep -q com.portablebrain.autoupdate && launchctl unload "$PLIST_DST" 2>/dev/null || true
sed "s#__BRAIN_ROOT__#$ROOT#g" "$PLIST_SRC" > "$PLIST_DST" && echo "  installed (paths set to $ROOT) -> $PLIST_DST"
launchctl load "$PLIST_DST" 2>/dev/null && echo "  loaded." || echo "  (load returned nonzero — checked in self-test)"

# --- 4. first full pass -------------------------------------------------------
echo "[4/5] Running first FULL pass (state + sidecar + semantic + mirror)..."
bash "$TOOLS/auto_update.sh" full || true
echo "  done (see $TOOLS/state.log)."

# --- 5. SELF-TEST -------------------------------------------------------------
echo "[5/5] SELF-TEST"
# T1 python
"$PY" -c "import sys;assert sys.version_info[0]==3" 2>/dev/null && ok "python3 present" || no "python3 missing"
# T2 _STATE.md
if [ -f "$ROOT/_STATE.md" ] && [ "$(wc -c < "$ROOT/_STATE.md")" -gt 800 ]; then ok "_STATE.md generated ($(wc -c < "$ROOT/_STATE.md") bytes)"; else no "_STATE.md missing/too small"; fi
# T3 gen_state re-run
"$PY" "$TOOLS/gen_state.py" --root "$ROOT" >/dev/null 2>&1 && ok "gen_state.py runs" || no "gen_state.py errored"
# T4 sidecar compiles+runs
"$PY" -m py_compile "$TOOLS/sidecar.py" 2>/dev/null && ok "sidecar.py compiles" || no "sidecar.py syntax error"
# T5 semantic
if "$PY" "$TOOLS/semantic_search.py" --build --root "$ROOT" 2>&1 | grep -qi "index built"; then ok "semantic index built (Ollama up)"; else warn "semantic index NOT built (Ollama down or no embed model) — keyword search still works; run later: python3 $TOOLS/semantic_search.py --build"; fi
# T6 session hook parses
[ -f "$ROOT/.claude/hooks/session_start_orient.sh" ] && { bash -n "$ROOT/.claude/hooks/session_start_orient.sh" 2>/dev/null && ok "session_start_orient.sh parses" || warn "session_start_orient.sh present but has a syntax issue"; } || warn "session_start_orient.sh not present (optional)"
# T7 brain_first hook runs on a sample without crashing
[ -f "$ROOT/.claude/hooks/brain_first_search.py" ] && { echo '{"prompt":"what is the project status?"}' | "$PY" "$ROOT/.claude/hooks/brain_first_search.py" >/dev/null 2>&1 && ok "brain_first_search.py runs (substantive prompt)" || warn "brain_first_search.py present but errored"; } || warn "brain_first_search.py not present (optional)"
[ -f "$ROOT/.claude/hooks/brain_first_search.py" ] && { echo '{"prompt":"hi"}' | "$PY" "$ROOT/.claude/hooks/brain_first_search.py" >/dev/null 2>&1 && ok "brain_first_search.py runs (trivial -> silent)" || warn "brain_first_search.py errored on trivial"; } || true
# T8 LaunchAgent loaded
launchctl list 2>/dev/null | grep -q com.portablebrain.autoupdate && ok "LaunchAgent loaded (watching + nightly)" || warn "LaunchAgent not loaded — run: launchctl load $PLIST_DST"
# T9 mirror present + worked
if [ -x "$ROOT/_tools/brain_automation/mirror_to_drive.sh" ]; then
  if tail -5 "$TOOLS/state.log" 2>/dev/null | grep -q "mirror synced"; then ok "mirror ran (phone will sync)"; else warn "mirror did not confirm — likely Full Disk Access: System Settings → Privacy & Security → Full Disk Access → add /bin/bash"; fi
else warn "mirror_to_drive.sh not found"; fi

echo "============================================================"
echo "RESULT: $PASS pass, $FAIL fail, $WARN warn"
echo "============================================================"
echo "----- _STATE.md preview (first 40 lines) -----"
head -40 "$ROOT/_STATE.md" 2>/dev/null
echo "----------------------------------------------"
if [ "$FAIL" -eq 0 ]; then
  echo "INSTALL OK. The brain now auto-updates its big picture on every change and on a nightly pass."
else
  echo "INSTALL had failures above — nothing destructive ran; uninstall with uninstall_bulletproof_brain.sh if needed."
fi
[ "$WARN" -gt 0 ] && echo "NOTE: warnings are non-blocking (Ollama / Full Disk Access). See messages above."
exit 0
