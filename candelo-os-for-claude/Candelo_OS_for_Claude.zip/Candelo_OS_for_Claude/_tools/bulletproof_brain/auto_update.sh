#!/bin/bash
# ==============================================================================
# auto_update.sh — Bulletproof Brain auto-trigger (FREE + LOCAL, no model cost)
# ==============================================================================
# Fired by the com.portablebrain.autoupdate LaunchAgent on TWO triggers:
#   - nightly (StartCalendarInterval ~3:33am)         -> a FULL pass
#   - file-change (WatchPaths on the brain root, debounced) -> a LIGHT pass
# One script decides which, so a single LaunchAgent covers both and cost stays
# bounded (the heavy walk runs at most ~once per 12h).
#
# FULL pass : _STATE.md regen + sidecar (new binaries) + semantic index rebuild
#             + FREE graphify reindex (`graphify update .`, $0, no API) + mirror.
# LIGHT pass: _STATE.md regen + mirror only (fast, ~1s; keeps the phone current
#             within minutes of any edit).
#
# COST: $0. Everything here is local Python / local Whisper / local Ollama /
# rsync / local tree-sitter. The nightly FULL pass now runs the FREE
# `graphify update .` CLI (step 3.5) to reindex code + structural document nodes
# for every current file — token cost 0, no Anthropic call, so
# (the post-Jun-15 Agent-SDK billing on `claude -p`) does NOT
# apply to it. It still deliberately does NOT run the billed headless
# `claude -p "/graphify"` unless explicitly opted in (step 4 / ALLOW_HEADLESS).
# Deep concept extraction of new markdown is the only model-needing piece; the
# free pass makes new files searchable immediately and an in-session agent or
# local Ollama can deepen them. Retrieval never blocks on any of it: _STATE.md +
# sidecars + the search hook all read files directly.
#
# Reversible: uninstall_bulletproof_brain.sh unloads the LaunchAgent.
# ==============================================================================
set -uo pipefail

ROOT="${BRAIN_ROOT:-__BRAIN_ROOT__}"
TOOLS="$ROOT/_tools/bulletproof_brain"
LOG="$TOOLS/state.log"
STAMP="$TOOLS/.last_full_run"
PY="$(command -v python3 || echo /usr/bin/python3)"
MODE="${1:-auto}"   # full | light | auto
FULL_EVERY_SECS=43200   # 12h

log(){ echo "[$(date '+%Y-%m-%d %H:%M:%S')] auto_update($MODE): $*" >> "$LOG"; }

cd "$ROOT" 2>/dev/null || { log "FATAL: brain root missing: $ROOT"; exit 0; }

# Decide full vs light when MODE=auto (the LaunchAgent's default).
if [ "$MODE" = "auto" ]; then
  NOW=$(date +%s)
  LAST=0
  [ -f "$STAMP" ] && LAST=$(cat "$STAMP" 2>/dev/null || echo 0)
  if [ $(( NOW - LAST )) -ge $FULL_EVERY_SECS ]; then MODE="full"; else MODE="light"; fi
fi
log "start (resolved mode=$MODE)"

# --- 1. Always: regenerate _STATE.md (read-side keystone; free) ---------------
if "$PY" "$TOOLS/gen_state.py" --root "$ROOT" >> "$LOG" 2>&1; then
  log "_STATE.md regenerated"
else
  log "WARN gen_state.py failed (see above)"
fi

if [ "$MODE" = "full" ]; then
  # --- 2. Sidecar: new binaries -> readable markdown (free, local) ------------
  if "$PY" "$TOOLS/sidecar.py" --root "$ROOT" >> "$LOG" 2>&1; then
    log "sidecar pass complete"
  else
    log "WARN sidecar.py failed"
  fi
  # --- 3. Semantic index rebuild (free, local Ollama; degrades if down) -------
  if "$PY" "$TOOLS/semantic_search.py" --build --root "$ROOT" >> "$LOG" 2>&1; then
    log "semantic index pass complete"
  else
    log "WARN semantic_search build failed"
  fi
  # --- 3.5 FREE graphify reindex (code + structural, $0, NO API, NO claude -p) -
  # This is the headless `graphify update .` CLI — tree-sitter AST + structural
  # document nodes for every current file. Token cost: 0 (verified 2026-06-23).
  # It is NOT the billed `claude -p "/graphify"` path; it never touches Anthropic
  # so does not apply. This is what indexes NEW files into the
  # graph automatically so neither the owner nor an agent has to run it by hand.
  # Deep concept extraction of new *markdown* (the LLM layer) still wants a model;
  # the free pass enters new docs as structural nodes (searchable), and the
  # opt-in step 4 (or any in-session agent / local Ollama) deepens them later.
  GRAPHIFY_BIN=""
  for g in "$(command -v graphify 2>/dev/null || true)" \
           "$HOME/.local/bin/graphify" "/opt/homebrew/bin/graphify" \
           "/usr/local/bin/graphify" "$HOME/.cargo/bin/graphify"; do
    [ -n "$g" ] && [ -x "$g" ] && { GRAPHIFY_BIN="$g"; break; }
  done
  # uv-tool fallback (uv tool install graphifyy puts it on its own shim path)
  if [ -z "$GRAPHIFY_BIN" ] && command -v uv >/dev/null 2>&1; then
    GRAPHIFY_BIN="uv tool run --from graphifyy graphify"
  fi
  if [ -n "$GRAPHIFY_BIN" ]; then
    GJSON="$ROOT/graphify-out/graph.json"
    BEFORE=$(stat -f %m "$GJSON" 2>/dev/null || echo 0)
    log "free graphify reindex: $GRAPHIFY_BIN update . (no LLM, \$0)"
    # graphify returns exit 1 when only the cosmetic graph.html write fails
    # (stale-perms / >5000-node skip) even though graph.json + report DID write,
    # so judge success by graph.json mtime advancing, not by exit code.
    ( cd "$ROOT" && $GRAPHIFY_BIN update . >> "$LOG" 2>&1 )
    AFTER=$(stat -f %m "$GJSON" 2>/dev/null || echo 0)
    if [ "$AFTER" -gt "$BEFORE" ]; then
      NODES=$("$PY" -c "import json;print(len(json.load(open('$GJSON'))['nodes']))" 2>/dev/null || echo "?")
      log "free graphify reindex OK — graph.json rewritten ($NODES nodes)"
    else
      log "WARN free graphify reindex did not rewrite graph.json (binary/perms? see above)"
    fi
  else
    log "WARN graphify binary not found — skipping free reindex (install: uv tool install graphifyy)"
  fi

  # --- 4. OPT-IN guarded headless graphify (DEFAULT OFF — money guard) --------
  # Only runs if the owner explicitly sets ALLOW_HEADLESS_GRAPHIFY=1 in the env file.
  # After Jun 15 2026 this bills Agent-SDK API rates .
  ENVF="$TOOLS/auto_update.env"
  ALLOW=0
  [ -f "$ENVF" ] && ALLOW=$(grep -E '^ALLOW_HEADLESS_GRAPHIFY=' "$ENVF" | tail -1 | cut -d= -f2 | tr -dc '0-9')
  if [ "${ALLOW:-0}" = "1" ]; then
    CLAUDE_BIN=""
    for c in "$(command -v claude 2>/dev/null || true)" \
             "$HOME/.local/bin/claude" "/opt/homebrew/bin/claude" \
             "/usr/local/bin/claude" "$HOME/.claude/local/claude"; do
      [ -n "$c" ] && [ -x "$c" ] && { CLAUDE_BIN="$c"; break; }
    done
    if [ -n "$CLAUDE_BIN" ]; then
      log "ALLOW_HEADLESS_GRAPHIFY=1 -> running headless /graphify (BILLS API after Jun 15)"
      ( cd "$ROOT" && "$CLAUDE_BIN" -p "/graphify . --update" --add-dir "$ROOT" --permission-mode acceptEdits >> "$LOG" 2>&1 ) || log "WARN headless graphify failed"
    else
      log "headless graphify requested but claude binary not found"
    fi
  else
    log "headless graphify skipped (opt-in OFF) — graph reindex stays the owner's interactive /graphify"
  fi
  date +%s > "$STAMP"
fi

# --- 4.7 One-time bootstrap: stand up the Crawl4AI research service ------------
# Additive + idempotent + reversible. Runs the local research-service installer
# ONCE, fully detached so it never blocks or slows a brain update, then never
# again (guarded by the .installed sentinel + a .installing in-progress marker).
# This is the "the owner does nothing" wire: the next file-change/nightly trigger
# after this script ships installs Crawl4AI on its own. $0 / local / no API.
# Disable by setting SKIP_CRAWL4AI_BOOTSTRAP=1 or deleting the installer.
CR_DIR="$ROOT/_tools/crawl4ai_research"
# Treat an .installing marker older than 30 min as abandoned (e.g. a stuck pip
# build) so a hardened retry isn't blocked forever.
if [ -f "$CR_DIR/.installing" ]; then
  MK=$(cat "$CR_DIR/.installing" 2>/dev/null || echo 0)
  [ $(( $(date +%s) - ${MK:-0} )) -ge 1800 ] && { log "crawl4ai bootstrap: clearing stale .installing marker"; rm -f "$CR_DIR/.installing"; }
fi
if [ "${SKIP_CRAWL4AI_BOOTSTRAP:-0}" != "1" ] \
   && [ -f "$CR_DIR/install_crawl4ai.sh" ] \
   && [ ! -f "$CR_DIR/.installed" ] && [ ! -f "$CR_DIR/.installing" ]; then
  date +%s > "$CR_DIR/.installing"
  log "crawl4ai bootstrap: launching one-time installer detached (logs -> install.log)"
  ( nohup bash "$CR_DIR/install_crawl4ai.sh" > "$CR_DIR/install.log" 2>&1; rm -f "$CR_DIR/.installing" ) &
fi

# --- 5. Mirror to Drive/iCloud (free; reuses the existing mirror) -------------
MIRROR="$ROOT/_tools/brain_automation/mirror_to_drive.sh"
if [ -x "$MIRROR" ]; then
  if bash "$MIRROR" >> "$LOG" 2>&1; then log "mirror synced"; else log "WARN mirror failed (check Full Disk Access)"; fi
else
  log "mirror script not found/executable: $MIRROR"
fi

log "done (mode=$MODE)"
exit 0
