#!/usr/bin/env python3
"""
gen_state.py — Bulletproof Brain READ-side keystone.

Builds `_STATE.md` at the brain root: the small (~2-4 KB), always-current
"big picture" that is loaded fully on EVERY surface (Claude Code via the
SessionStart hook, Cowork/Dispatch via CLAUDE.md STEP 0 + the Drive mirror).

It is DETERMINISTIC and EXTRACTIVE — it pulls real lines from the canonical
files (no model call, no invented prose, $0). Every section is wrapped in its
own try/except so a parse problem in one source degrades to a "(could not
read)" line instead of crashing the whole digest.

Sources, all already-canonical:
  - Ventures + status   : CLAUDE.md §2 portfolio table + each venture's
                          canonical current_state.md FACTS/Snapshot table.
  - Recent decisions    : the Change Log (last N "Change ID: CHG-####" blocks).
  - Open items / on-owner: latest Research/<date> — Session Handoff.md.
  - What changed recently: brain_intake_ledger.md PENDING INDEX (newest rows).
  - Graph freshness     : newest .md mtime vs graphify-out/graph.json mtime
                          -> flags "graph reindex pending" (interactive, free).
  - Pointer index       : a small curated map (stable).

Usage:  python3 _tools/bulletproof_brain/gen_state.py [--root <brain root>]
Writes: <root>/_STATE.md   (and prints the path + byte size)
"""

import os
import re
import sys
import glob
import datetime

# --------------------------------------------------------------------------- #
# Brain root resolution
# --------------------------------------------------------------------------- #
def find_root():
    for i, a in enumerate(sys.argv):
        if a == "--root" and i + 1 < len(sys.argv):
            return os.path.abspath(sys.argv[i + 1])
    env = os.environ.get("BRAIN_ROOT")
    if env and os.path.isdir(env):
        return os.path.abspath(env)
    # .../_tools/bulletproof_brain/gen_state.py -> up two = brain root
    return os.path.abspath(os.path.join(os.path.dirname(__file__), "..", ".."))

ROOT = find_root()

# --------------------------------------------------------------------------- #
# Config (GENERALIZED) — edit projects.json to describe YOUR brain.
# --------------------------------------------------------------------------- #
# This file ships generic. All project/business specifics live in
# `projects.json` next to this script. Defaults below are placeholders so the
# digest still generates before you customize. Every path is optional and
# degrades to a "(not found)" line if the file doesn't exist.
import json as _json

DEFAULT_CONFIG = {
    # Display-ordered list of your projects/ventures.
    "projects": ["ProjectOne", "ProjectTwo"],
    # Per-project current-state files (first that exists & isn't a redirect wins).
    "project_state_files": {
        "ProjectOne": ["ProjectOne/current_state.md"],
        "ProjectTwo": ["ProjectTwo/current_state.md"],
    },
    # Registry of flagship assets + BUILD-vs-DEPLOYED status (optional).
    "flagship_file": "_architecture/flagship_assets.md",
    # Change log (optional).
    "change_log_file": "_registries/Change Log.md",
    # Intake / pending-capture ledger (optional).
    "intake_ledger_file": "_architecture/brain_intake_ledger.md",
    # Killed/retired projects: {label: note} appended to the snapshot (optional).
    "killed_projects": {},
    # Curated pointer index (label -> path) shown at the bottom of _STATE.md.
    "pointers": [
        ["Priorities / what to work on", "GOV-0001_Priority_Framework.md"],
        ["Build phases per project", "GOV-0002_Build_Phases.md"],
        ["Flagship assets (BUILD vs DEPLOYED)", "_architecture/flagship_assets.md"],
        ["Tools in the stack", "CLAUDE.md  (\u00a73)"],
    ],
}

def _load_config():
    cfg = dict(DEFAULT_CONFIG)
    here = os.path.dirname(os.path.abspath(__file__))
    for cand in (os.path.join(here, "projects.json"),
                 os.path.join(ROOT, "projects.json")):
        try:
            with open(cand, "r", encoding="utf-8") as fh:
                cfg.update(_json.load(fh))
            break
        except (OSError, ValueError):
            continue
    return cfg

CONFIG = _load_config()

def clip(s, n):
    """Truncate to <= n chars on a word boundary, add an ellipsis if cut."""
    s = s.strip()
    if len(s) <= n:
        return s
    cut = s[:n].rsplit(" ", 1)[0].rstrip(" ,.;—-")
    return cut + "…"

def rd(rel):
    """Read a file under ROOT, return text or '' on any failure."""
    try:
        with open(os.path.join(ROOT, rel), "r", encoding="utf-8", errors="ignore") as fh:
            return fh.read()
    except OSError:
        return ""

# --------------------------------------------------------------------------- #
# Venture state
# --------------------------------------------------------------------------- #
# Canonical current_state.md per live venture (redirect-aware fallbacks tried
# in order; first that exists AND is not a redirect stub wins).
VENTURE_STATE_FILES = CONFIG["project_state_files"]

# Live ventures, in display order. Used by the flagship + big-picture sections so
# a venture that has BUILT something but never registered it shows up as a loud gap.
LIVE_VENTURES = CONFIG["projects"]

def pick_state_file(candidates):
    for rel in candidates:
        txt = rd(rel)
        if not txt:
            continue
        # skip redirect stubs that just point elsewhere
        if "REDIRECT" in txt[:400] or "redirect" in txt[:400]:
            continue
        return rel, txt
    # fall back to the first that exists at all
    for rel in candidates:
        txt = rd(rel)
        if txt:
            return rel, txt
    return candidates[0], ""

def grab_fact(txt, *labels):
    """Pull the canonical value cell for a labelled table row, cleaned to a
    short phrase. Returns '' if not found."""
    for label in labels:
        # markdown row:  | **Label** | value | source |
        m = re.search(r"\|\s*\*{0,2}" + re.escape(label) + r"\*{0,2}\s*\|(.+?)\|",
                      txt, re.IGNORECASE)
        if m:
            cell = m.group(1)
            cell = re.sub(r"\*\*|__", "", cell)          # strip bold
            cell = re.sub(r"`([^`]*)`", r"\1", cell)      # strip code ticks
            cell = re.sub(r"\s+", " ", cell).strip()
            # keep it short: first sentence / clause
            cell = re.split(r"(?<=[.)])\s|—| -- ", cell)[0].strip(" .—-")
            return cell[:120]
    return ""

def venture_status_from_claudemd():
    """Parse the CLAUDE.md §2 portfolio table -> {venture: state-sentence}."""
    out = {}
    txt = rd("CLAUDE.md")
    if not txt:
        return out
    for line in txt.splitlines():
        if not line.strip().startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) < 3:
            continue
        name = re.sub(r"\*\*|\(.*?\)", "", cells[0]).strip()
        if not name or name.lower() in ("venture", "---"):
            continue
        state = re.sub(r"\*\*", "", cells[2])
        state = re.sub(r"\s+", " ", state).strip()
        if state and not state.startswith("---"):
            # first sentence only
            state = re.split(r"(?<=[.])\s", state)[0].strip()
            out[name] = state[:160]
    return out

def section_ventures():
    lines = ["## Ventures (live snapshot)", ""]
    claude_states = venture_status_from_claudemd()
    order = LIVE_VENTURES
    for v in order:
        try:
            rel, txt = pick_state_file(VENTURE_STATE_FILES[v])
            cust = grab_fact(txt, "Paying customers", "Paying customers")
            mrr = grab_fact(txt, "MRR")
            # find the matching CLAUDE.md state line (loose key match)
            state = ""
            for k, s in claude_states.items():
                if v.split()[0].lower() in k.lower():
                    state = s
                    break
            bits = []
            if state:
                bits.append(state)
            tail = []
            if cust:
                tail.append(f"customers: {cust}")
            if mrr:
                tail.append(f"MRR: {mrr}")
            line = f"- **{v}** — " + (state if state else "(status file: %s)" % rel)
            if tail:
                line += f"  _({'; '.join(tail)})_"
            lines.append(line)
        except Exception as e:  # never crash the digest on one venture
            lines.append(f"- **{v}** — (could not read state: {e})")
    # retired/killed projects (from config)
    for _label, _note in CONFIG.get("killed_projects", {}).items():
        lines.append(f"- **{_label}** — {_note}")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Flagship assets — BUILD vs DEPLOYED   (the Black Box structural fix)
# --------------------------------------------------------------------------- #
# WHY: a "built but never registered" asset is the worst failure class — a finished
# thing that's invisible to the big picture, so every orientation reads the OLD state
# of a project and the crown jewel is missed. The registry (flagship_file) MUST carry,
# per project, the flagship assets + whether each is BUILT vs DEPLOYED. This reads that
# registry and ALWAYS emits the section; a project with no registered assets is flagged
# LOUDLY so a built asset can never be silently absent again.
FLAGSHIP_FILE = CONFIG["flagship_file"]

def _status_class(status):
    """Map a Status cell to a class from its first word (see flagship_assets.md)."""
    toks = re.findall(r"[A-Za-z]+", status)
    token = toks[0].upper() if toks else ""
    if token in ("DEPLOYED", "LIVE"):
        return "DEPLOYED"
    if token == "BUILT":
        return "BUILT"
    if token == "BLOCKED":
        return "BLOCKED"
    if token in ("INBUILD",):
        return "INBUILD"
    if token == "PLANNED":
        return "PLANNED"
    if token in ("NOTBUILT", "NOT"):
        return "NOTBUILT"
    return "OTHER"

def parse_flagships():
    """Parse flagship_assets.md -> ({venture: [(asset, status, class), ...]}, found)."""
    txt = rd(FLAGSHIP_FILE)
    out = {}
    if not txt:
        return out, False
    cur = None
    for line in txt.splitlines():
        h = re.match(r"^##\s+(.+?)\s*$", line)
        if h:
            name = h.group(1).strip()
            cur = None
            for v in LIVE_VENTURES:
                if v.lower() == name.lower():
                    cur = v
                    out.setdefault(v, [])
                    break
            continue
        if cur and line.strip().startswith("|"):
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if len(cells) < 2:
                continue
            asset, status = cells[0], cells[1]
            if asset.lower() == "asset" or set(asset) <= set("-: |"):
                continue  # header / separator row
            out[cur].append((asset, status, _status_class(status)))
    return out, True

_MARKS = {
    "DEPLOYED": "✅ DEPLOYED",
    "BUILT":    "⚠ BUILT — NOT DEPLOYED",
    "BLOCKED":  "⚠ BLOCKED (external)",
    "INBUILD":  "… in build",
    "PLANNED":  "○ planned",
    "NOTBUILT": "✗ not built",
    "OTHER":    "•",
}

def section_flagships():
    data, found = parse_flagships()
    lines = ["## Flagship assets — BUILD vs DEPLOYED (read before calling any venture 'done')", ""]
    if not found:
        lines.append(f"- ⚠ **`{FLAGSHIP_FILE}` not found** — flagship/asset status is UNKNOWN for "
                     f"the whole portfolio. This is the Black Box failure class (a built crown "
                     f"jewel invisible to the big picture). Create the registry.")
        lines.append("")
        return "\n".join(lines)
    for v in LIVE_VENTURES:
        rows = data.get(v, [])
        if not rows:
            lines.append(f"- **{v}** — ⚠ **NO FLAGSHIP ASSETS REGISTERED.** If this venture has "
                         f"built anything, it is missing from the brain — add rows to `{FLAGSHIP_FILE}`.")
            continue
        dep = sum(1 for *_x, c in rows if c == "DEPLOYED")
        blt = sum(1 for *_x, c in rows if c in ("BUILT", "BLOCKED"))
        lines.append(f"- **{v}** — {dep} deployed / {blt} built-not-shipped:")
        for asset, status, cls in rows:
            lines.append(f"    - {_MARKS.get(cls, '•')} — {asset}  _({clip(status, 90)})_")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# One-screen big-picture map + done-vs-pending reconcile
# --------------------------------------------------------------------------- #
def section_bigpicture_map():
    data, _found = parse_flagships()
    claude_states = venture_status_from_claudemd()
    lines = ["## One-screen big picture (whole portfolio at a glance)", ""]
    total_dep = total_built = 0
    for v in LIVE_VENTURES:
        rows = data.get(v, [])
        dep = sum(1 for *_x, c in rows if c == "DEPLOYED")
        blt = sum(1 for *_x, c in rows if c in ("BUILT", "BLOCKED"))
        total_dep += dep
        total_built += blt
        state = ""
        for k, s in claude_states.items():
            if v.split()[0].lower() in k.lower():
                state = s
                break
        flag = f" · ⚠ {blt} built-not-shipped" if blt else ""
        lines.append(f"- **{v}**: {clip(state or '(see snapshot)', 64)} · {dep} live{flag}")
    for _label, _note in CONFIG.get("killed_projects", {}).items():
        lines.append(f"- **{_label}**: {_note}")
    lines.append("")
    lines.append(f"**Done-vs-pending (assets):** {total_dep} deployed portfolio-wide · "
                 f"**{total_built} flagship assets BUILT but NOT shipped** — the nearest revenue "
                 f"step is shipping these, not building new.")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Recent decisions (Change Log)
# --------------------------------------------------------------------------- #
def section_decisions(n=6):
    lines = ["## Recent decisions (newest Change-Log entries)", ""]
    txt = rd(CONFIG["change_log_file"])
    if not txt:
        lines.append("- (change log unreadable)")
        lines.append("")
        return "\n".join(lines)
    rows = []
    for m in re.finditer(
        r"Change ID:\s*(CHG-\d+)\s*Date:\s*([0-9-]+).*?Change Type:\s*(.+?)\s*Target Registry",
        txt, re.DOTALL):
        cid, date, ctype = m.group(1), m.group(2), m.group(3)
        ctype = re.sub(r"\s+", " ", ctype).strip()
        ctype = re.split(r"—| - |\. ", ctype)[0].strip()  # short phrase
        try:
            num = int(cid.split("-")[1])
        except Exception:
            num = 0
        rows.append((num, cid, date, ctype[:90]))
    rows.sort(key=lambda r: r[0])
    for _num, cid, date, ctype in rows[-n:][::-1]:
        lines.append(f"- {cid} ({date}) — {ctype}")
    if len(rows) == 0:
        lines.append("- (no change-log entries parsed)")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Open items + waiting-on-owner (latest Session Handoff)
# --------------------------------------------------------------------------- #
def latest_handoff():
    pats = sorted(glob.glob(os.path.join(ROOT, "Research", "*Session Handoff*.md")))
    if not pats:
        return None, ""
    pats.sort(key=lambda p: os.path.getmtime(p))
    p = pats[-1]
    try:
        with open(p, "r", encoding="utf-8", errors="ignore") as fh:
            return os.path.relpath(p, ROOT), fh.read()
    except OSError:
        return os.path.relpath(p, ROOT), ""

def extract_block(txt, header):
    """Return bullet lines under a '## header' until the next '## '."""
    m = re.search(r"^##+\s*" + re.escape(header) + r".*$", txt, re.MULTILINE | re.IGNORECASE)
    if not m:
        return []
    start = m.end()
    nxt = re.search(r"^##+\s", txt[start:], re.MULTILINE)
    body = txt[start: start + nxt.start()] if nxt else txt[start:]
    out = []
    for ln in body.splitlines():
        s = ln.strip()
        if s.startswith("-") or s.startswith("*"):
            s = re.sub(r"\*\*", "", s.lstrip("-* ").strip())
            s = re.sub(r"\s+", " ", s)
            if s:
                out.append(clip(s, 190))
    return out

def section_open_items():
    rel, txt = latest_handoff()
    lines = ["## Open items / waiting-on-owner", ""]
    if not txt:
        lines.append("- (no session handoff found)")
        lines.append("")
        return "\n".join(lines)
    bullets = extract_block(txt, "CLAUDE-ADDED")[:6]
    if not bullets:
        bullets = extract_block(txt, "Open")[:6]
    for b in bullets:
        lines.append(f"- {b}")
    # single open question
    q = re.search(r"##+\s*Single open question.*?\n+(.+)", txt, re.IGNORECASE | re.DOTALL)
    if q:
        qline = re.sub(r"\*\*", "", q.group(1).splitlines()[0]).strip()
        if qline:
            lines.append(f"- **Open question:** {qline[:200]}")
    lines.append(f"")
    lines.append(f"_source: {rel}_")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# What changed recently (ledger pending captures)
# --------------------------------------------------------------------------- #
def section_recent_captures(n=5):
    lines = ["## Recently captured (pending next graph index)", ""]
    txt = rd(CONFIG["intake_ledger_file"])
    if not txt:
        lines.append("- (ledger unreadable)")
        lines.append("")
        return "\n".join(lines)
    rows = []
    grab = False
    for ln in txt.splitlines():
        if "PENDING INDEX" in ln:
            grab = True
            continue
        if grab and ln.strip().startswith("|"):
            cells = [c.strip() for c in ln.strip().strip("|").split("|")]
            # only real dated capture rows (skips header + the example/instruction row)
            if len(cells) >= 3 and re.match(r"\d{4}-\d{2}-\d{2}", cells[0]):
                date = cells[0]
                what = re.sub(r"\*\*", "", cells[1])
                what = re.split(r"\. ", what)[0]
                rows.append(f"- {date} — {clip(what, 130)}")
        elif grab and ln.strip().startswith("##"):
            break
    for r in rows[-n:][::-1]:
        lines.append(r)
    if not rows:
        lines.append("- (nothing pending)")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Graph freshness flag
# --------------------------------------------------------------------------- #
def section_graph_freshness():
    lines = ["## Brain index freshness", ""]
    gj = os.path.join(ROOT, "graphify-out", "graph.json")
    try:
        gmt = os.path.getmtime(gj)
    except OSError:
        lines.append("- graph.json not found — run `/graphify . --update` interactively in Claude Code.")
        lines.append("")
        return "\n".join(lines)
    # newest markdown anywhere (excluding noise dirs)
    newest = 0.0
    newest_f = ""
    skip = ("graphify-out", "_canon_backup", "node_modules", ".git", "_tools/bulletproof_brain/backups")
    for dp, dn, fn in os.walk(ROOT):
        if any(s in dp for s in skip):
            continue
        for f in fn:
            if f.endswith(".md"):
                fp = os.path.join(dp, f)
                try:
                    mt = os.path.getmtime(fp)
                except OSError:
                    continue
                if mt > newest:
                    newest, newest_f = mt, os.path.relpath(fp, ROOT)
    gdt = datetime.datetime.fromtimestamp(gmt).strftime("%Y-%m-%d %H:%M")
    if newest > gmt + 60:
        lines.append(f"- ⚠ **Graph reindex pending.** Markdown newer than the graph exists "
                     f"(newest: `{newest_f}`). The big picture above is still current "
                     f"(it reads the files directly), but structural graph queries are stale. "
                     f"Run `/graphify . --update` **interactively** in Claude Code on the Mac "
                     f"(free on Max — do NOT use headless `claude -p` for this after Jun 15; it bills API rates).")
    else:
        lines.append(f"- ✓ Graph current (last built {gdt}); no newer markdown pending.")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Pointer index (curated, stable)
# --------------------------------------------------------------------------- #
POINTERS = [tuple(p) for p in CONFIG["pointers"]]

def section_pointers():
    lines = ["## Pointer index (go deeper)", ""]
    for label, path in POINTERS:
        lines.append(f"- {label} → `{path}`")
    lines.append("")
    return "\n".join(lines)

# --------------------------------------------------------------------------- #
# Assemble
# --------------------------------------------------------------------------- #
def build():
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M PT")
    header = (
        "---\n"
        "title: the brain — Current Big Picture (_STATE.md)\n"
        f"generated: {now}\n"
        "generator: _tools/bulletproof_brain/gen_state.py (auto, $0, no model call)\n"
        "status: ALWAYS-LOADED orientation layer — read this FIRST on every surface\n"
        "do_not_edit: regenerated automatically; edit the source files, not this digest\n"
        "---\n\n"
        "# the brain — The Big Picture (read me first)\n\n"
        "> This is the always-current digest loaded at the start of every session on every "
        "surface (Claude Code, Cowork, Dispatch/phone). It is regenerated automatically from "
        "the canonical files whenever the brain updates, so it is never stale. For anything "
        "deeper than a headline, follow the pointer index at the bottom.\n>\n"
        "> **Prove-it on open:** restate today's date, the flagship BUILD-vs-DEPLOYED status "
        "per venture (below), the done-vs-pending line, and one paragraph of big picture — so "
        "a miss (like a built crown jewel gone absent) is caught in one glance.\n\n"
    )
    parts = [
        header,
        section_bigpicture_map(),
        section_ventures(),
        section_flagships(),
        section_decisions(),
        section_open_items(),
        section_recent_captures(),
        section_graph_freshness(),
        section_pointers(),
        f"_Digest regenerated {now} by gen_state.py. If this timestamp is old, the auto-trigger "
        f"didn't run — check `_tools/bulletproof_brain/state.log`._\n",
    ]
    return "\n".join(parts)

def main():
    out = build()
    dest = os.path.join(ROOT, "_STATE.md")
    with open(dest, "w", encoding="utf-8") as fh:
        fh.write(out)
    print(f"wrote {dest} ({len(out.encode('utf-8'))} bytes)")

if __name__ == "__main__":
    main()
